// Мостик svodik ⇄ программа для Windows (WebView2). Даёт странице тот же window.svodikOverlay,
// что был в версии на Electron, поэтому сама страница не меняется.
// Сообщения в программу: строка «команда␟номер␟аргументы…» (␟ = символ \u001f).
// Ответы и события из программы приходят как JSON-объекты.
(() => {
  const W = window.chrome && window.chrome.webview; if (!W || window.svodikOverlay) return;
  const I = window.__SVK_INIT || {};
  const US = '\u001f';
  const handlers = {}; const on = (t, cb) => (handlers[t] = handlers[t] || []).push(cb);
  const emit = (t, d) => (handlers[t] || []).forEach(f => { try { f(d); } catch (e) { console.error(e); } });
  let seq = 0; const waits = new Map();
  const post = (cmd, ...a) => W.postMessage([cmd, 0, ...a].map(x => x == null ? '' : String(x)).join(US));
  const call = (cmd, ...a) => new Promise(res => { const id = ++seq; waits.set(id, res); W.postMessage([cmd, id, ...a].map(x => x == null ? '' : String(x)).join(US)); });
  W.addEventListener('message', e => {
    const m = e.data; if (!m || typeof m !== 'object') return;
    if (m.type === 'reply') { const r = waits.get(m.id); if (r) { waits.delete(m.id); r(m.data); } return; }
    emit(m.type, m);
  });
  let cfg = Object.assign({ win: true }, I.config || {});
  on('config', m => { cfg = m.cfg; });
  const b64 = str => { const u = new TextEncoder().encode(str); let s = ''; for (let i = 0; i < u.length; i += 0x8000) s += String.fromCharCode.apply(null, u.subarray(i, i + 0x8000)); return btoa(s); };

  // ---- хранилище: файлы в папке «Документы\svodik» ----
  const ID_RE = /^[A-Za-z0-9_-]{1,64}$/, safeKey = k => String(k).replace(/[^A-Za-z0-9_.-]/g, '_').slice(0, 80);
  let pendingS = null, sTimer = 0;
  const flushS = () => { clearTimeout(sTimer); if (pendingS == null) return Promise.resolve(); const j = pendingS; pendingS = null; try { JSON.parse(j); } catch { return Promise.resolve(); } return call('fsWrite', 'settings.json', b64(j)); };
  const kvFind = async k => { const base = safeKey(k), names = (await call('fsList', 'files')) || []; return names.filter(n => n === base || n.startsWith(base + '.')); };
  const MIME = { jpg: 'image/jpeg', jpeg: 'image/jpeg', png: 'image/png', webp: 'image/webp', gif: 'image/gif' };
  const store = {
    settings: () => { try { return I.settings ? JSON.parse(I.settings) : null; } catch { return null; } },
    saveSettings: json => { pendingS = json; clearTimeout(sTimer); sTimer = setTimeout(flushS, 500); },
    all: async () => {
      const list = (await call('docsAll')) || [], out = [];
      for (const t of list) { try { const d = JSON.parse(t); if (d && ID_RE.test(d.id || '')) out.push(d); } catch {} }
      return out;
    },
    put: doc => { if (!doc || !ID_RE.test(doc.id || '')) return Promise.reject(new Error('bad id')); return call('fsWrite', 'documents/' + doc.id + '.json', b64(JSON.stringify(doc))).then(r => { if (r !== true) throw new Error(r || 'не удалось записать файл'); }); },
    del: id => ID_RE.test(id || '') ? call('fsDel', 'documents/' + id + '.json') : Promise.resolve(),
    kvGet: async k => {
      const f = (await kvFind(k))[0]; if (!f) return null;
      const mime = MIME[(f.split('.').pop() || '').toLowerCase()];
      if (mime) return `data:${mime};base64,` + await call('fsRead', 'files/' + f, 1);
      return await call('fsRead', 'files/' + f, 0);
    },
    kvSet: async (k, v) => {
      for (const f of await kvFind(k)) await call('fsDel', 'files/' + f);
      const m = typeof v === 'string' && v.match(/^data:image\/(jpeg|jpg|png|webp|gif);base64,(.*)$/s);
      if (m) return call('fsWrite', 'files/' + safeKey(k) + '.' + (m[1] === 'jpeg' ? 'jpg' : m[1]), m[2]);
      return call('fsWrite', 'files/' + safeKey(k) + '.txt', b64(String(v)));
    },
    kvDel: async k => { for (const f of await kvFind(k)) await call('fsDel', 'files/' + f); }
  };
  // перед выходом программа просит дописать отложенные настройки
  on('flush', async () => { try { await flushS(); } catch {} post('flushed'); });

  // ---- обновления: проверка на GitHub здесь, загрузка и замена файла — в программе ----
  const REPO = 'anjeladavalka/svodik', PAGE = `https://github.com/${REPO}/releases/latest`, VERSION = I.version || '0.0.0';
  const parseVer = v => { const s = String(v || ''); let m = s.match(/(\d+)\.(\d+)\.(\d+)/); if (m) return [+m[1], +m[2], +m[3]]; m = s.match(/(\d+)(?:\.(\d+))?/); if (!m) return null; const f = m[2] || '0'; return f.length >= 2 ? [+m[1], +f[0], +f.slice(1)] : [+m[1], +f, 0]; };
  const isNewer = (a, b) => { const x = parseVer(a), y = parseVer(b); if (!x || !y) return false; for (let i = 0; i < 3; i++) if (x[i] !== y[i]) return x[i] > y[i]; return false; };
  const label = v => { const p = parseVer(v); return p ? (p[0] === 0 ? 'beta ' : '') + p[0] + '.' + p[1] + (p[2] ? String(p[2]) : '') : String(v || ''); };
  let ust = { state: 'idle', current: label(VERSION), page: PAGE, canInstall: true }, rel = null, file = null, busy = false;
  const setU = patch => { ust = Object.assign({ current: label(VERSION), page: PAGE, canInstall: true }, patch); emit('ustate', ust); };
  async function check(manual) {
    if (busy || ust.state === 'downloading' || ust.state === 'ready' || ust.state === 'installing') return ust;
    busy = true; setU({ state: 'checking' });
    try {
      const ctl = new AbortController(), t = setTimeout(() => ctl.abort(), 15000);
      const r = await fetch(`https://api.github.com/repos/${REPO}/releases/latest`, { signal: ctl.signal, cache: 'no-store' }); clearTimeout(t);
      if (r.status === 404) { rel = null; setU({ state: 'none', manual }); return ust; }
      if (r.status === 403 || r.status === 429) throw new Error('GitHub временно ограничил проверки — попробуйте через час');
      if (!r.ok) throw new Error('GitHub ответил ошибкой ' + r.status);
      const j = await r.json(), tag = j.tag_name || j.name || '';
      if (j.draft || j.prerelease || !isNewer(tag, VERSION)) { rel = null; setU({ state: 'none', manual }); return ust; }
      const as = Array.isArray(j.assets) ? j.assets : [];
      const a = as.find(x => /^svodik\.exe$/i.test(x.name)) || as.find(x => /^svodik.*\.exe$/i.test(x.name)) || as.find(x => /\.exe$/i.test(x.name));
      rel = { tag, latest: label(tag), notes: String(j.body || '').slice(0, 4000), page: j.html_url || PAGE, url: a && a.browser_download_url, size: a ? a.size : 0 };
      setU({ state: 'available', latest: rel.latest, notes: rel.notes, page: rel.page, total: rel.size, canInstall: !!rel.url, manual });
      post('updateFound', rel.latest);
    } catch (e) { setU({ state: 'error', error: e.name === 'AbortError' || e instanceof TypeError ? 'Нет связи с GitHub' : e.message, manual }); }
    finally { busy = false; }
    return ust;
  }
  on('dl', m => { if (ust.state === 'downloading') setU(Object.assign({}, ust, { received: m.received, progress: m.total ? m.received / m.total : 0 })); });
  on('dlDone', m => {
    const base = rel ? { latest: rel.latest, notes: rel.notes, page: rel.page, total: rel.size } : {};
    if (m.ok) { file = m.file; setU(Object.assign({ state: 'ready', progress: 1 }, base)); }
    else setU(Object.assign({ state: 'error', error: m.error || 'Не получилось скачать', retry: 'download' }, base));
  });
  const update = {
    state: () => ust,
    check: () => check(true),
    download: () => {
      if (!rel || !rel.url) { post('openUrl', rel ? rel.page : PAGE); return Promise.resolve(ust); }
      setU({ state: 'downloading', received: 0, progress: 0, latest: rel.latest, notes: rel.notes, page: rel.page, total: rel.size });
      post('download', rel.url, rel.size || 0, rel.tag);
      return Promise.resolve(ust);
    },
    install: async () => {
      if (ust.state !== 'ready' || !file) return ust;
      await flushS().catch(() => {});
      setU(Object.assign({}, ust, { state: 'installing' }));
      const r = await call('install', file);
      if (r !== true) setU(Object.assign({}, ust, { state: 'ready', error: r || 'Не удалось установить обновление' }));
      return ust;
    },
    page: () => post('openUrl', rel ? rel.page : PAGE),
    onState: cb => on('ustate', cb),
    onOpen: cb => on('openUpdate', () => cb())
  };
  const auto = () => cfg.autoUpdate !== false;
  setTimeout(() => { if (auto()) check(false); }, 10000);
  setInterval(() => { if (auto()) check(false); }, 6 * 3600 * 1000);

  // ---- окно: перетаскивание за полоску заголовка ----
  addEventListener('mousedown', e => {
    if (e.button !== 0 || !e.target.closest) return;
    if (e.target.closest('.ovbar') && !e.target.closest('button,kbd,input,a,.ov-cap,.upd-pill')) { e.preventDefault(); post('drag'); }
  }, true);

  window.svodikOverlay = {
    native: true,
    hide: () => post('hide'),
    onShown: cb => on('shown', () => cb()),
    onHiding: cb => on('hiding', () => cb()),
    config: () => cfg,
    onConfig: cb => on('config', m => cb(m.cfg)),
    set: (key, val) => { if (key === 'autoUpdate' && val) setTimeout(() => check(false), 300); return call('set', key, val && typeof val === 'object' ? JSON.stringify(val) : val == null ? '' : (val === true ? 1 : val === false ? 0 : val)).then(c => { if (c && typeof c === 'object') { const e = c.error; cfg = Object.assign({}, c); delete cfg.error; if (e) c.error = e; } return c; }); },
    setHotkey: key => call('hotkey', key),
    pauseHotkey: v => post('hotkeyPause', v ? 1 : 0),
    bounds: () => call('bounds'),
    resize: (w, h) => post('resize', Math.round(w), Math.round(h)),
    onKey: cb => on('key', m => cb(m.k)),
    onCapture: cb => on('capture', m => cb(m.c)),
    toggleCapture: () => post('captureToggle'),
    wantKeyboard: () => post('wantKeyboard'),
    onEdit: cb => on('edit', m => cb(m.d)),
    onWheel: cb => on('wheel', m => cb(m.d)),
    onCursor: cb => on('cursor', m => cb(m.d)),
    fx: v => post('fx', v ? 1 : 0),
    copy: text => post('copy', String(text || '')),
    store,
    update
  };
  // ошибки страницы — в журнал svodik.log, чтобы по нему можно было понять, что случилось
  let nErr = 0;
  addEventListener('error', e => { if (nErr++ < 20) post('log', 'ошибка: ' + (e.message || e) + ' @' + (e.lineno || 0)); });
  addEventListener('unhandledrejection', e => { if (nErr++ < 20) post('log', 'ошибка: ' + ((e.reason && e.reason.message) || e.reason)); });
  addEventListener('DOMContentLoaded', () => post('ready'));
})();
