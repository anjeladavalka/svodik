svodik для Windows — исходники (beta 0.6). Автор: anjelacold

svodik.c        программа: окно поверх игры, перехват клавиатуры, значок у часов, файлы, обновление, удаление
util.h          строки, UTF-8, base64, файлы, журнал
wv2.h           описания WebView2 для C (сделаны gen_wv2.py из webview2-com-sys)
shim.js         мостик между страницей и программой (window.svodikOverlay)
selftest.h      самопроверка: svodik.exe --selftest отчёт.txt
page-source.html  читаемый исходник страницы; в exe встраивается защищённая сборка page.html
build.sh        сборка mingw-w64: положить рядом page.html (защищённая страница) и запустить
