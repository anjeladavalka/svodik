# Генерирует wv2.h: объявления интерфейсов WebView2 для C в точном порядке методов (из webview2-com-sys/bindings.rs)
import re, sys
s = open(sys.argv[1]).read()
def names(n):
    m = re.search(r'pub struct ' + n + r'_Vtbl \{(.*?)\n\}', s, re.S)
    f = re.findall(r'^\s*pub (\w+):', m.group(1), re.M)
    base = re.search(r'pub base__: ([\w:]+)_Vtbl', m.group(1)).group(1).split('::')[-1]
    return base, f[1:]
def chain(n):
    base, own = names(n)
    return (chain(base) if base != 'IUnknown' else []) + own
def iid(n):
    m = re.search(r'define_interface!\(\s*' + n + r',\s*' + n + r'_Vtbl,\s*0x([0-9a-f_]+)\s*\)', s)
    h = m.group(1).replace('_', '')
    return '{0x%s,0x%s,0x%s,{%s}}' % (h[0:8], h[8:12], h[12:16], ','.join('0x' + h[16 + 2*i:18 + 2*i] for i in range(8)))
# сигнатуры методов, которые вызываем (остальные — просто места в таблице)
SIG = {
 'CreateCoreWebView2Controller': 'HWND parent, void *handler',
 'BrowserVersionString': 'LPWSTR *v',
 'SetIsVisible': 'BOOL v', 'SetBounds': 'RECT r', 'MoveFocus': 'int reason', 'NotifyParentWindowPositionChanged': '', 'Close': '',
 'CoreWebView2': 'void **wv', 'SetDefaultBackgroundColor': 'COREWEBVIEW2_COLOR c',
 'Settings': 'void **settings', 'Navigate': 'LPCWSTR uri', 'add_NavigationStarting': 'void *handler, EventRegistrationToken *t',
 'add_ProcessFailed': 'void *handler, EventRegistrationToken *t', 'AddScriptToExecuteOnDocumentCreated': 'LPCWSTR js, void *handler',
 'RemoveScriptToExecuteOnDocumentCreated': 'LPCWSTR id', 'ExecuteScript': 'LPCWSTR js, void *handler', 'Reload': '', 'PostWebMessageAsJson': 'LPCWSTR json',
 'add_WebMessageReceived': 'void *handler, EventRegistrationToken *t', 'BrowserProcessId': 'UINT32 *pid',
 'add_NewWindowRequested': 'void *handler, EventRegistrationToken *t', 'OpenDevToolsWindow': '',
 'SetVirtualHostNameToFolderMapping': 'LPCWSTR host, LPCWSTR folder, int access',
 'SetIsStatusBarEnabled': 'BOOL v', 'SetAreDevToolsEnabled': 'BOOL v', 'SetAreDefaultContextMenusEnabled': 'BOOL v', 'SetIsZoomControlEnabled': 'BOOL v',
 'SetAreDefaultScriptDialogsEnabled': 'BOOL v', 'SetIsBuiltInErrorPageEnabled': 'BOOL v',
 'TrySuspend': 'void *handler', 'Resume': '', 'IsSuspended': 'BOOL *v',
 'TryGetWebMessageAsString': 'LPWSTR *str', 'Uri': 'LPWSTR *uri', 'SetHandled': 'BOOL v', 'SetCancel': 'BOOL v', 'ProcessFailedKind': 'int *kind',
}
IFACES = {
 'ICoreWebView2Environment': 'ICoreWebView2Environment', 'ICoreWebView2Controller2': 'ICoreWebView2Controller2',
 'ICoreWebView2_3': 'ICoreWebView2_3', 'ICoreWebView2Settings': 'ICoreWebView2Settings',
 'ICoreWebView2WebMessageReceivedEventArgs': 'ICoreWebView2WebMessageReceivedEventArgs',
 'ICoreWebView2NewWindowRequestedEventArgs': 'ICoreWebView2NewWindowRequestedEventArgs',
 'ICoreWebView2NavigationStartingEventArgs': 'ICoreWebView2NavigationStartingEventArgs',
 'ICoreWebView2ProcessFailedEventArgs': 'ICoreWebView2ProcessFailedEventArgs',
}
out = ['/* wv2.h — сгенерировано gen_wv2.py из webview2-com-sys 0.39.1. Не править руками. */', '#pragma once', '#include <windows.h>',
       'typedef struct { BYTE A, R, G, B; } COREWEBVIEW2_COLOR;', 'typedef struct { INT64 value; } EventRegistrationToken;']
for n in IFACES:
    meth = chain(n)
    out.append(f'/* {n}: {len(meth)} методов после IUnknown */')
    out.append(f'typedef struct {n} {n};')
    out.append(f'typedef struct {n}Vtbl {{')
    out.append(f'  HRESULT (STDMETHODCALLTYPE *QueryInterface)({n} *This, REFIID riid, void **ppv);')
    out.append(f'  ULONG (STDMETHODCALLTYPE *AddRef)({n} *This);')
    out.append(f'  ULONG (STDMETHODCALLTYPE *Release)({n} *This);')
    seen = {}
    for i, m in enumerate(meth):
        nm = m if m not in seen else f'{m}_{i}'; seen[m] = 1
        if m in SIG:
            args = SIG[m]
            out.append(f'  HRESULT (STDMETHODCALLTYPE *{nm})({n} *This{", " + args if args else ""});')
        else:
            out.append(f'  void *{nm};')
    out.append(f'}} {n}Vtbl;')
    out.append(f'struct {n} {{ const {n}Vtbl *lpVtbl; }};')
for n in ['ICoreWebView2Environment', 'ICoreWebView2Controller', 'ICoreWebView2Controller2', 'ICoreWebView2', 'ICoreWebView2_3', 'ICoreWebView2Settings',
          'ICoreWebView2CreateCoreWebView2EnvironmentCompletedHandler', 'ICoreWebView2CreateCoreWebView2ControllerCompletedHandler',
          'ICoreWebView2WebMessageReceivedEventHandler', 'ICoreWebView2NewWindowRequestedEventHandler', 'ICoreWebView2NavigationStartingEventHandler',
          'ICoreWebView2AddScriptToExecuteOnDocumentCreatedCompletedHandler', 'ICoreWebView2ProcessFailedEventHandler', 'ICoreWebView2ExecuteScriptCompletedHandler',
          'ICoreWebView2TrySuspendCompletedHandler']:
    out.append(f'static const GUID IID_{n} = {iid(n)};')
# число методов для самопроверки
for n in IFACES: out.append(f'enum {{ N_{n} = {len(chain(n))} }};')
open('wv2.h', 'w').write('\n'.join(out) + '\n')
print('ok', {n: len(chain(n)) for n in IFACES})
