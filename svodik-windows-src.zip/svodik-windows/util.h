/* util.h — служебные функции svodik: строки, UTF-8, base64, JSON, файлы, журнал. */
#pragma once
#ifndef UNICODE
#define UNICODE
#endif
#ifndef _UNICODE
#define _UNICODE
#endif
#define WIN32_LEAN_AND_MEAN
#ifndef _WIN32_WINNT
#define _WIN32_WINNT 0x0A00
#endif
#include <windows.h>
#include <shlobj.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <wchar.h>

/* ---------- растущая строка ---------- */
typedef struct { wchar_t *p; size_t n, cap; } WBuf;
static void wb_grow(WBuf *b, size_t add) {
  if (b->n + add + 1 <= b->cap) return;
  size_t c = b->cap ? b->cap : 256; while (c < b->n + add + 1) c *= 2;
  b->p = (wchar_t *)realloc(b->p, c * sizeof(wchar_t)); b->cap = c;
}
static void wb_putn(WBuf *b, const wchar_t *s, size_t n) { wb_grow(b, n); memcpy(b->p + b->n, s, n * sizeof(wchar_t)); b->n += n; b->p[b->n] = 0; }
static void wb_put(WBuf *b, const wchar_t *s) { if (s) wb_putn(b, s, wcslen(s)); }
static void wb_putc(WBuf *b, wchar_t c) { wb_putn(b, &c, 1); }
static void wb_fmt(WBuf *b, const wchar_t *fmt, ...) {
  wchar_t tmp[1024]; va_list ap; va_start(ap, fmt); int n = _vsnwprintf(tmp, 1023, fmt, ap); va_end(ap);
  if (n < 0) n = 1023; tmp[n] = 0; wb_putn(b, tmp, (size_t)n);
}
static void wb_free(WBuf *b) { free(b->p); b->p = NULL; b->n = b->cap = 0; }
static const wchar_t *wb_str(WBuf *b) { if (!b->p) wb_grow(b, 0), b->p[0] = 0; return b->p; }
/* строка как JSON-литерал в кавычках */
static void wb_json(WBuf *b, const wchar_t *s, size_t n) {
  wb_putc(b, L'"');
  for (size_t i = 0; i < n; i++) {
    wchar_t c = s[i];
    if (c == L'"') wb_put(b, L"\\\"");
    else if (c == L'\\') wb_put(b, L"\\\\");
    else if (c == L'\n') wb_put(b, L"\\n");
    else if (c == L'\r') wb_put(b, L"\\r");
    else if (c == L'\t') wb_put(b, L"\\t");
    else if (c < 0x20 || c == 0x2028 || c == 0x2029) wb_fmt(b, L"\\u%04x", (unsigned)c);
    else wb_putc(b, c);
  }
  wb_putc(b, L'"');
}
static void wb_jsonz(WBuf *b, const wchar_t *s) { if (s) wb_json(b, s, wcslen(s)); else wb_put(b, L"null"); }

/* ---------- UTF-8 ⇄ UTF-16 ---------- */
static wchar_t *u8_to_w(const char *s, int len) {
  if (len < 0) len = (int)strlen(s);
  int n = MultiByteToWideChar(CP_UTF8, 0, s, len, NULL, 0);
  wchar_t *w = (wchar_t *)malloc((size_t)(n + 1) * sizeof(wchar_t));
  MultiByteToWideChar(CP_UTF8, 0, s, len, w, n); w[n] = 0; return w;
}
static char *w_to_u8(const wchar_t *w, int len, int *outLen) {
  if (len < 0) len = (int)wcslen(w);
  int n = WideCharToMultiByte(CP_UTF8, 0, w, len, NULL, 0, NULL, NULL);
  char *s = (char *)malloc((size_t)n + 1);
  WideCharToMultiByte(CP_UTF8, 0, w, len, s, n, NULL, NULL); s[n] = 0;
  if (outLen) *outLen = n; return s;
}

/* ---------- base64 ---------- */
static const char B64[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
static unsigned char *b64_decode(const wchar_t *s, size_t *outLen) {
  size_t n = wcslen(s); unsigned char *o = (unsigned char *)malloc(n * 3 / 4 + 4); size_t k = 0; unsigned v = 0; int bits = 0;
  for (size_t i = 0; i < n; i++) {
    wchar_t c = s[i]; int d;
    if (c >= L'A' && c <= L'Z') d = c - L'A'; else if (c >= L'a' && c <= L'z') d = c - L'a' + 26;
    else if (c >= L'0' && c <= L'9') d = c - L'0' + 52; else if (c == L'+' || c == L'-') d = 62; else if (c == L'/' || c == L'_') d = 63;
    else continue;   /* «=», переводы строк и прочее пропускаем */
    v = (v << 6) | (unsigned)d; bits += 6;
    if (bits >= 8) { bits -= 8; o[k++] = (unsigned char)((v >> bits) & 0xFF); }
  }
  *outLen = k; return o;
}
static void wb_b64(WBuf *b, const unsigned char *d, size_t n) {
  wb_grow(b, (n + 2) / 3 * 4);
  for (size_t i = 0; i < n; i += 3) {
    unsigned v = (unsigned)d[i] << 16 | (i + 1 < n ? (unsigned)d[i + 1] << 8 : 0) | (i + 2 < n ? d[i + 2] : 0);
    b->p[b->n++] = (wchar_t)B64[(v >> 18) & 63]; b->p[b->n++] = (wchar_t)B64[(v >> 12) & 63];
    b->p[b->n++] = i + 1 < n ? (wchar_t)B64[(v >> 6) & 63] : L'='; b->p[b->n++] = i + 2 < n ? (wchar_t)B64[v & 63] : L'=';
  }
  b->p[b->n] = 0;
}

/* ---------- файлы ---------- */
static unsigned char *read_file(const wchar_t *path, size_t *len) {
  HANDLE h = CreateFileW(path, GENERIC_READ, FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE, NULL, OPEN_EXISTING, 0, NULL);
  if (h == INVALID_HANDLE_VALUE) return NULL;
  LARGE_INTEGER sz; if (!GetFileSizeEx(h, &sz) || sz.QuadPart > 512LL * 1024 * 1024) { CloseHandle(h); return NULL; }
  unsigned char *buf = (unsigned char *)malloc((size_t)sz.QuadPart + 2); DWORD got = 0; size_t total = 0;
  while (total < (size_t)sz.QuadPart && ReadFile(h, buf + total, (DWORD)((size_t)sz.QuadPart - total > 1 << 20 ? 1 << 20 : (size_t)sz.QuadPart - total), &got, NULL) && got) total += got;
  CloseHandle(h); buf[total] = 0; buf[total + 1] = 0; if (len) *len = total; return buf;
}
/* запись через временный файл и замену «одним движением»: файл не бывает наполовину записан */
static BOOL write_file_atomic(const wchar_t *path, const void *data, size_t len) {
  wchar_t tmp[MAX_PATH + 8]; _snwprintf(tmp, MAX_PATH + 7, L"%s.tmp", path); tmp[MAX_PATH + 7] = 0;
  HANDLE h = CreateFileW(tmp, GENERIC_WRITE, 0, NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
  if (h == INVALID_HANDLE_VALUE) return FALSE;
  DWORD put = 0; BOOL ok = TRUE; size_t done = 0;
  while (done < len) { DWORD chunk = (DWORD)(len - done > (1 << 20) ? (1 << 20) : len - done); if (!WriteFile(h, (const char *)data + done, chunk, &put, NULL) || !put) { ok = FALSE; break; } done += put; }
  FlushFileBuffers(h); CloseHandle(h);
  if (!ok) { DeleteFileW(tmp); return FALSE; }
  for (int t = 0; t < 10; t++) { if (MoveFileExW(tmp, path, MOVEFILE_REPLACE_EXISTING | MOVEFILE_WRITE_THROUGH)) return TRUE; Sleep(30); }
  DeleteFileW(tmp); return FALSE;
}
static BOOL file_exists(const wchar_t *p) { DWORD a = GetFileAttributesW(p); return a != INVALID_FILE_ATTRIBUTES && !(a & FILE_ATTRIBUTE_DIRECTORY); }
static BOOL dir_exists(const wchar_t *p) { DWORD a = GetFileAttributesW(p); return a != INVALID_FILE_ATTRIBUTES && (a & FILE_ATTRIBUTE_DIRECTORY); }
/* создать папку вместе со всеми недостающими родительскими (любые буквы в имени) */
static void ensure_dir(const wchar_t *p) {
  if (!p || !*p || dir_exists(p)) return;
  wchar_t buf[MAX_PATH]; wcsncpy(buf, p, MAX_PATH - 1); buf[MAX_PATH - 1] = 0;
  size_t n = wcslen(buf); while (n > 3 && (buf[n - 1] == L'\\' || buf[n - 1] == L'/')) buf[--n] = 0;
  for (size_t i = 3; i <= n; i++) {
    if (buf[i] == L'\\' || buf[i] == L'/' || buf[i] == 0) {
      wchar_t c = buf[i]; buf[i] = 0;
      if (i > 2 && !dir_exists(buf)) CreateDirectoryW(buf, NULL);
      buf[i] = c;
    }
  }
}
static void path_join(wchar_t *out, const wchar_t *a, const wchar_t *b) { _snwprintf(out, MAX_PATH - 1, L"%s\\%s", a, b); out[MAX_PATH - 1] = 0; }
/* удалить папку со всем содержимым */
static void delete_tree(const wchar_t *dir) {
  wchar_t mask[MAX_PATH], p[MAX_PATH]; WIN32_FIND_DATAW fd; path_join(mask, dir, L"*");
  HANDLE f = FindFirstFileW(mask, &fd);
  if (f != INVALID_HANDLE_VALUE) {
    do {
      if (!wcscmp(fd.cFileName, L".") || !wcscmp(fd.cFileName, L"..")) continue;
      path_join(p, dir, fd.cFileName);
      if (fd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) delete_tree(p);
      else { SetFileAttributesW(p, FILE_ATTRIBUTE_NORMAL); DeleteFileW(p); }
    } while (FindNextFileW(f, &fd));
    FindClose(f);
  }
  RemoveDirectoryW(dir);
}
static BOOL dir_empty(const wchar_t *dir) {
  wchar_t mask[MAX_PATH]; WIN32_FIND_DATAW fd; path_join(mask, dir, L"*");
  HANDLE f = FindFirstFileW(mask, &fd); if (f == INVALID_HANDLE_VALUE) return TRUE;
  BOOL empty = TRUE;
  do { if (wcscmp(fd.cFileName, L".") && wcscmp(fd.cFileName, L"..")) { empty = FALSE; break; } } while (FindNextFileW(f, &fd));
  FindClose(f); return empty;
}
/* файл можно открыть на запись — значит, его больше никто не держит (программа закрылась) */
static BOOL file_free(const wchar_t *p) {
  HANDLE h = CreateFileW(p, GENERIC_READ | GENERIC_WRITE, 0, NULL, OPEN_EXISTING, 0, NULL);
  if (h == INVALID_HANDLE_VALUE) return GetLastError() == ERROR_FILE_NOT_FOUND || GetLastError() == ERROR_PATH_NOT_FOUND;
  CloseHandle(h); return TRUE;
}
static const wchar_t *base_name(const wchar_t *p) { const wchar_t *s = wcsrchr(p, L'\\'); const wchar_t *t = wcsrchr(p, L'/'); if (t > s) s = t; return s ? s + 1 : p; }
static BOOL starts_with_i(const wchar_t *s, const wchar_t *pre) { return _wcsnicmp(s, pre, wcslen(pre)) == 0; }
static BOOL ends_with_i(const wchar_t *s, const wchar_t *suf) { size_t a = wcslen(s), b = wcslen(suf); return a >= b && _wcsicmp(s + a - b, suf) == 0; }

/* ---------- журнал ---------- */
static wchar_t g_logPath[MAX_PATH];
static void logw(const wchar_t *fmt, ...) {
  if (!g_logPath[0]) return;
  wchar_t msg[2048]; va_list ap; va_start(ap, fmt); int n = _vsnwprintf(msg, 2047, fmt, ap); va_end(ap); if (n < 0) n = 2047; msg[n] = 0;
  SYSTEMTIME t; GetLocalTime(&t);
  wchar_t line[2200]; _snwprintf(line, 2199, L"%04d-%02d-%02d %02d:%02d:%02d  %s\r\n", t.wYear, t.wMonth, t.wDay, t.wHour, t.wMinute, t.wSecond, msg); line[2199] = 0;
  WIN32_FILE_ATTRIBUTE_DATA a;
  if (GetFileAttributesExW(g_logPath, GetFileExInfoStandard, &a) && a.nFileSizeLow > 300000) { wchar_t old[MAX_PATH + 8]; _snwprintf(old, MAX_PATH + 7, L"%s.old", g_logPath); old[MAX_PATH + 7] = 0; MoveFileExW(g_logPath, old, MOVEFILE_REPLACE_EXISTING); }
  int len; char *u = w_to_u8(line, -1, &len);
  HANDLE h = CreateFileW(g_logPath, FILE_APPEND_DATA, FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE, NULL, OPEN_ALWAYS, 0, NULL);
  if (h != INVALID_HANDLE_VALUE) { DWORD w; WriteFile(h, u, (DWORD)len, &w, NULL); CloseHandle(h); }
  free(u);
}
