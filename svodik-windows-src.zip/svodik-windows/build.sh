#!/bin/sh
# Сборка svodik.exe для Windows (mingw-w64)
set -e
cd "$(dirname "$0")"
x86_64-w64-mingw32-windres --codepage=65001 -O coff svodik.rc res.o
x86_64-w64-mingw32-gcc -std=gnu11 -O2 -Wall -Wextra -Wno-unused-parameter -Wno-cast-function-type -Wno-missing-field-initializers -Wno-misleading-indentation \
  -municode -mwindows -o svodik.exe svodik.c res.o \
  -luser32 -lgdi32 -lshell32 -lole32 -loleaut32 -ldwmapi -lwinhttp -luuid -lcomctl32 -ladvapi32 -s
ls -la svodik.exe
