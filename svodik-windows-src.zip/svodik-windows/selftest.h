/* selftest.h — самопроверка svodik без окна движка (её можно запускать и под Wine):
 * svodik.exe --selftest <файл-отчёт>. Проверяет файлы, настройки, клавиши, обновление, переход со старой версии,
 * удаление ярлыков и запуск окна с перехватом клавиатуры. */
static int st_fail, st_total; static FILE *st_out;
static void st_check(int ok, const char *what) { st_total++; if (!ok) st_fail++; fprintf(st_out, "%s  %s\n", ok ? "OK  " : "FAIL", what); fflush(st_out); }
/* дочерний запуск из самопроверки: записываем, с какими параметрами нас запустили, и выходим */
static int selftest_child(void) {
  wchar_t mark[MAX_PATH]; if (!GetEnvironmentVariableW(L"SVODIK_SELFTEST_CHILD", mark, MAX_PATH)) return 0;
  int len; char *u = w_to_u8(GetCommandLineW(), -1, &len); HANDLE h = CreateFileW(mark, GENERIC_WRITE, 0, NULL, CREATE_ALWAYS, 0, NULL);
  if (h != INVALID_HANDLE_VALUE) { DWORD w; WriteFile(h, u, (DWORD)len, &w, NULL); CloseHandle(h); } free(u); return 1;
}
static int st_file_is(const wchar_t *p, const char *content) { size_t n; char *d = (char *)read_file(p, &n); int ok = d && n == strlen(content) && !memcmp(d, content, n); free(d); return ok; }
static void st_write(const wchar_t *p, const char *content) { write_file_atomic(p, content, strlen(content)); }
static int st_same_file(const wchar_t *a, const wchar_t *b) { size_t n1, n2; unsigned char *x = read_file(a, &n1), *y = read_file(b, &n2); int ok = x && y && n1 == n2 && !memcmp(x, y, n1); free(x); free(y); return ok; }
static int st_wait_file(const wchar_t *p, int ms) { for (int t = 0; t < ms / 100; t++) { if (file_exists(p)) { Sleep(100); return 1; } Sleep(100); } return 0; }

static int run_selftest(const wchar_t *outPath) {
  st_out = _wfopen(outPath, L"w"); if (!st_out) return 99;
  wchar_t tmp[MAX_PATH], root[MAX_PATH], p[MAX_PATH], q[MAX_PATH]; GetTempPathW(MAX_PATH, tmp);
  _snwprintf(root, MAX_PATH - 1, L"%ssvodik-selftest-%lu", tmp, GetTickCount()); ensure_dir(root);
  path_join(gAppData, root, L"appdata"); ensure_dir(gAppData); path_join(gIni, gAppData, L"svodik.ini"); path_join(g_logPath, gAppData, L"svodik.log");
  path_join(gLocal, root, L"local"); path_join(gDocsDefault, root, L"Документы svodik (тест)"); cfg_defaults();

  /* строки */
  { unsigned char raw[300]; for (int i = 0; i < 300; i++) raw[i] = (unsigned char)(i * 7 + 3); WBuf b = {0}; wb_b64(&b, raw, 300); size_t n; unsigned char *d = b64_decode(wb_str(&b), &n);
    st_check(n == 300 && !memcmp(d, raw, 300), "base64 туда и обратно"); free(d); wb_free(&b); }
  { const wchar_t *src = L"Привет, svodik ✓ «кавычки»"; char *u = w_to_u8(src, -1, NULL); wchar_t *w = u8_to_w(u, -1); st_check(!wcscmp(w, src), "UTF-8 туда и обратно"); free(u); free(w); }
  { WBuf b = {0}; wb_json(&b, L"a\"b\\c\nd\x01", 8); st_check(!wcscmp(wb_str(&b), L"\"a\\\"b\\\\c\\nd\\u0001\""), "JSON: кавычки, слэши, переводы строк"); wb_free(&b); }
  /* горячие клавиши */
  { Accel a; int ok = parse_accel(L"Alt+Q", &a) && a.vk == 'Q' && a.alt && !a.ctrl;
    ok = ok && parse_accel(L"Ctrl+Alt+W", &a) && a.vk == 'W' && a.alt && a.ctrl && a.mods == (MOD_CONTROL | MOD_ALT);
    ok = ok && parse_accel(L"F7", &a) && a.vk == 0x76 && !a.mods; ok = ok && parse_accel(L"Alt+`", &a) && a.vk == 0xC0;
    ok = ok && parse_accel(L"num5", &a) && a.vk == 0x65; ok = ok && parse_accel(L"Ctrl+Shift+Space", &a) && a.vk == 0x20 && a.shift;
    ok = ok && !parse_accel(L"Alt+Ы", &a) && !parse_accel(L"", &a);
    st_check(ok, "разбор горячих клавиш"); }
  /* пути внутри папки документов */
  st_check(rel_ok(L"documents/abc-1_2.json") && rel_ok(L"files/bg.jpg") && rel_ok(L"settings.json") && rel_ok(L"files"), "разрешённые пути");
  st_check(!rel_ok(L"../x") && !rel_ok(L"documents/../x.json") && !rel_ok(L"documents/a/b.json") && !rel_ok(L"C:/Windows/x") && !rel_ok(L"other/x.json") && !rel_ok(L"documents/.hidden") && !rel_ok(L"documents/имя.json"), "запрещённые пути");
  /* документы */
  { WBuf cap = {0}; gTestCapture = &cap; ensure_data_dirs();
    char *u = w_to_u8(L"{\"id\":\"abc\",\"tab\":\"УК\",\"html\":\"<p>Пункт 1.1</p>\"}", -1, NULL); WBuf b64 = {0}; wb_b64(&b64, (unsigned char *)u, strlen(u)); free(u);
    fs_write(5, L"documents/abc.json", wb_str(&b64)); st_check(wcsstr(wb_str(&cap), L"\"id\":5,\"data\":true") != NULL, "запись документа");
    cap.n = 0;
    fs_write(6, L"../evil.json", wb_str(&b64)); st_check(wcsstr(wb_str(&cap), L"недопустимое") != NULL, "запись за пределы папки запрещена"); cap.n = 0;
    fs_docs_all(7); st_check(wcsstr(wb_str(&cap), L"\\\"tab\\\":\\\"УК\\\"") != NULL, "чтение всех документов (русские буквы)"); cap.n = 0;
    fs_list(8, L"documents"); st_check(wcsstr(wb_str(&cap), L"[\"abc.json\"]") != NULL, "список файлов"); cap.n = 0;
    fs_read(9, L"documents/abc.json", 0); st_check(wcsstr(wb_str(&cap), L"Пункт 1.1") != NULL, "чтение файла текстом"); cap.n = 0;
    unsigned char png[] = { 0x89, 'P', 'N', 'G', 0, 1, 2, 255 }; WBuf pb = {0}; wb_b64(&pb, png, 8);
    fs_write(10, L"files/wall.png", wb_str(&pb)); cap.n = 0; fs_read(11, L"files/wall.png", 1);
    WBuf want = {0}; wb_fmt(&want, L"\"data\":\"%s\"", wb_str(&pb)); st_check(wcsstr(wb_str(&cap), wb_str(&want)) != NULL, "картинка туда и обратно (base64)"); cap.n = 0;
    fs_del(12, L"documents/abc.json"); fs_docs_all(13); st_check(wcsstr(wb_str(&cap), L"\"data\":[]") != NULL, "удаление документа"); cap.n = 0;
    path_join(p, data_dir(), L"documents\\abc.json.tmp"); st_check(!file_exists(p), "после записи не остаётся временных файлов");
    wb_free(&b64); wb_free(&pb); wb_free(&want); gTestCapture = NULL; wb_free(&cap); }
  /* настройки окна */
  { cfg_defaults(); st_check(cfg.captureKeys && !cfg.lite, "по умолчанию: клавиатура сразу у svodik, облегчённый режим выключен");
    wcscpy(cfg.hotkey, L"Ctrl+Alt+W"); cfg.alpha = .8; cfg.gameMode = 0; cfg.hasBounds = 1; SetRect(&cfg.bounds, 10, 20, 900, 700); wcscpy(cfg.dataDir, L"D:\\Мои документы\\svodik"); cfg.captureKeys = 0; cfg.lite = 1; cfg_save();
    cfg_defaults(); cfg_load(); st_check(!wcscmp(cfg.hotkey, L"Ctrl+Alt+W") && cfg.alpha > .79 && cfg.alpha < .81 && !cfg.gameMode && cfg.hasBounds && cfg.bounds.right == 900 && !wcscmp(cfg.dataDir, L"D:\\Мои документы\\svodik") && !cfg.captureKeys && cfg.lite, "настройки окна сохраняются и читаются");
    cfg_defaults(); }
  { DeleteFileW(gIni); path_join(p, gAppData, L"overlay.json");
    st_write(p, "{\n  \"hotkey\": \"Ctrl+Shift+Space\",\n  \"onTop\": false,\n  \"alpha\": 0.9,\n  \"size\": \"l\",\n  \"gameMode\": true,\n  \"dataDir\": null\n}");
    cfg_load(); st_check(!wcscmp(cfg.hotkey, L"Ctrl+Shift+Space") && !cfg.onTop && cfg.alpha > .89 && !wcscmp(cfg.size, L"l") && cfg.gameMode && !cfg.dataDir[0] && !cfg.firstRun, "перенос настроек из прежней версии (overlay.json)");
    cfg_defaults(); }
  /* обновление: файлы рядом с svodik.exe не появляются, старый заменяется новым */
  wchar_t self[MAX_PATH]; GetModuleFileNameW(NULL, self, MAX_PATH);
  { wchar_t place[MAX_PATH], upd[MAX_PATH], mark[MAX_PATH]; path_join(place, root, L"Загрузки"); ensure_dir(place); path_join(gExe, place, L"svodik.exe"); wcscpy(gRun, gExe);
    st_write(gExe, "OLD-VERSION");
    path_join(p, data_dir(), L"update"); ensure_dir(p); path_join(upd, p, L"svodik-update-v0.7.0.exe"); st_write(upd, "MZ-not-a-program");
    const wchar_t *e = install_update(upd);
    st_check(e != NULL && st_file_is(gExe, "OLD-VERSION") && st_file_is(upd, "MZ-not-a-program"), "неудачная установка откатывается, старый svodik на месте");
    CopyFileW(self, upd, FALSE); path_join(mark, root, L"child1.txt"); SetEnvironmentVariableW(L"SVODIK_SELFTEST_CHILD", mark);
    e = install_update(upd);
    wchar_t old[MAX_PATH + 8]; _snwprintf(old, MAX_PATH + 7, L"%s.old", gExe);
    st_check(e == NULL && st_same_file(gExe, self) && st_file_is(old, "OLD-VERSION") && !file_exists(upd), "обновление встаёт на место svodik.exe");
    int got = st_wait_file(mark, 5000); size_t n; char *args = got ? (char *)read_file(mark, &n) : NULL;
    st_check(args && strstr(args, "--after-update") && strstr(args, "--cleanup") && strstr(args, "svodik.exe.old"), "новая версия запускается и знает, что удалить");
    free(args); SetEnvironmentVariableW(L"SVODIK_SELFTEST_CHILD", NULL);
    /* следующий запуск убирает остатки */
    st_write(old, "x"); path_join(q, place, L"svodik-update.exe"); st_write(q, "x"); path_join(p, place, L"мой файл.txt"); st_write(p, "x");
    path_join(mark, data_dir(), L"update\\svodik-update-v0.5.exe.part"); st_write(mark, "x");
    clean_update_files();
    path_join(mark, data_dir(), L"update");
    st_check(!file_exists(old) && !file_exists(q) && file_exists(p) && !dir_exists(mark) && file_exists(gExe), "уборка: только файлы обновлений, чужие файлы на месте");
  }
  /* переход с версии на Electron: новая встаёт на место svodik.exe и запускает его */
  { wchar_t place[MAX_PATH], target[MAX_PATH], mark[MAX_PATH]; path_join(place, root, L"Рабочий стол"); ensure_dir(place); path_join(target, place, L"svodik.exe"); st_write(target, "ELECTRON-0.54");
    path_join(p, data_dir(), L"update"); ensure_dir(p); path_join(gRun, p, L"svodik-update-v0.6.0.exe"); CopyFileW(self, gRun, FALSE);
    path_join(mark, root, L"child2.txt"); SetEnvironmentVariableW(L"SVODIK_SELFTEST_CHILD", mark);
    int ok = legacy_takeover(target, target);
    int got = st_wait_file(mark, 5000); size_t n; char *args = got ? (char *)read_file(mark, &n) : NULL;
    st_check(ok && st_same_file(target, self) && args && strstr(args, "--cleanup") && strstr(args, "svodik-update-v0.6.0.exe"), "переход со старой версии: svodik.exe заменён и запущен");
    free(args); SetEnvironmentVariableW(L"SVODIK_SELFTEST_CHILD", NULL); }
  /* ярлыки при удалении */
  { wchar_t lnkDir[MAX_PATH], lnk[MAX_PATH], other[MAX_PATH]; path_join(lnkDir, root, L"Desktop"); ensure_dir(lnkDir); path_join(gExe, root, L"Загрузки\\svodik.exe"); wcscpy(gRun, gExe);
    path_join(lnk, lnkDir, L"svodik.lnk"); path_join(other, lnkDir, L"Другая программа.lnk"); int made = 0;
    for (int i = 0; i < 2; i++) {
      IShellLinkW *sl = NULL; IPersistFile *pf = NULL;
      if (SUCCEEDED(CoCreateInstance(&CLSID_ShellLink, NULL, CLSCTX_INPROC_SERVER, &IID_IShellLinkW, (void **)&sl))) {
        sl->lpVtbl->SetPath(sl, i ? L"C:\\Windows\\notepad.exe" : gExe);
        if (SUCCEEDED(sl->lpVtbl->QueryInterface(sl, &IID_IPersistFile, (void **)&pf))) { if (SUCCEEDED(pf->lpVtbl->Save(pf, i ? other : lnk, TRUE))) made++; pf->lpVtbl->Release(pf); }
        sl->lpVtbl->Release(sl);
      }
    }
    if (made == 2) {
      WBuf cap = {0}; gTestCapture = &cap; remove_shortcuts_in(lnkDir, 0); gTestCapture = NULL;
      if (wcschr(wb_str(&cap), L'?') && file_exists(lnk)) st_check(file_exists(other), "ярлыки: Wine не хранит русские буквы в ярлыках — проверено только, что чужой ярлык цел");
      else st_check(!file_exists(lnk) && file_exists(other), "удаляются только ярлыки svodik");
      wb_free(&cap);
    }
    else st_check(1, "ярлыки: создать тестовые не удалось — проверка пропущена"); }
  /* окно, значок у часов, горячая клавиша и перехват клавиатуры */
  { WNDCLASSEXW wc = { sizeof wc }; wc.lpfnWndProc = WndProc; wc.hInstance = gInst; wc.lpszClassName = L"svodikSelfTest"; RegisterClassExW(&wc);
    gWnd = CreateWindowExW(WS_EX_APPWINDOW | WS_EX_TOPMOST | WS_EX_NOACTIVATE, L"svodikSelfTest", L"svodik", WS_POPUP, 100, 100, 800, 500, NULL, NULL, gInst, NULL);
    st_check(gWnd != NULL, "окно создаётся");
    if (gWnd) {
      apply_look(); tray_add(); int hk = register_hotkey(L"Ctrl+Alt+F11"); st_check(hk, "горячая клавиша регистрируется");
      WBuf cap = {0}; gTestCapture = &cap; gPageReady = 1; cfg.gameMode = 1;
      show_win(); st_check(IsWindowVisible(gWnd), "окно показывается"); st_check(capture == 1 || captureBroken, "перехват клавиатуры включается (или честно сообщает об ошибке)");
      MSG m; ULONGLONG t0 = GetTickCount64(); while (GetTickCount64() - t0 < 600) { while (PeekMessageW(&m, NULL, 0, 0, PM_REMOVE)) DispatchMessageW(&m); Sleep(10); }
      hide_win(); t0 = GetTickCount64(); while (GetTickCount64() - t0 < 400) { while (PeekMessageW(&m, NULL, 0, 0, PM_REMOVE)) DispatchMessageW(&m); Sleep(10); }
      st_check(!IsWindowVisible(gWnd) && capture == -1 && !hKb, "окно прячется, перехват снимается");
      st_check(wcsstr(wb_str(&cap), L"\"type\":\"shown\"") && wcsstr(wb_str(&cap), L"\"type\":\"hiding\""), "страница узнаёт о показе и скрытии");
      /* команды, которые присылает страница («команда␟номер␟аргументы») */
      cap.n = 0; on_web_message(L"set\x1f" L"21\x1f" L"alpha\x1f" L"0.5"); st_check(wcsstr(wb_str(&cap), L"\"id\":21") && wcsstr(wb_str(&cap), L"\"alpha\":0.50"), "команда set: плотность стекла");
      cap.n = 0; on_web_message(L"hotkey\x1f" L"22\x1f" L"Ctrl+Alt+F10"); st_check(wcsstr(wb_str(&cap), L"\"ok\":true") && !wcscmp(cfg.hotkey, L"Ctrl+Alt+F10"), "команда hotkey: смена горячей клавиши");
      cap.n = 0; on_web_message(L"hotkey\x1f" L"23\x1f" L"Alt+Ы"); st_check(wcsstr(wb_str(&cap), L"\"ok\":false") && !wcscmp(cfg.hotkey, L"Ctrl+Alt+F10"), "неверная клавиша не ломает прежнюю");
      cap.n = 0; on_web_message(L"bounds\x1f" L"24"); st_check(wcsstr(wb_str(&cap), L"\"width\":") != NULL, "команда bounds: размеры окна");
      on_web_message(L"resize\x1f" L"0\x1f" L"900\x1f" L"560"); { RECT r; GetWindowRect(gWnd, &r); double sc = scale_of(gWnd); st_check(abs((int)((r.right - r.left) / sc) - 900) <= 2, "команда resize: размер меняется"); }
      cap.n = 0; on_web_message(L"fsWrite\x1f" L"25\x1f" L"documents/x1.json\x1f" L"eyJpZCI6IngxIn0="); cap.n = 0; on_web_message(L"docsAll\x1f" L"26"); st_check(wcsstr(wb_str(&cap), L"{\\\"id\\\":\\\"x1\\\"}") != NULL, "команды файлов: запись и чтение документа");
      cap.n = 0; on_web_message(L"copy\x1f" L"0\x1f" L"Текст для буфера"); { wchar_t *t, *h; clip_get(&t, &h); st_check(t && !wcscmp(t, L"Текст для буфера"), "копирование в буфер обмена"); free(t); free(h); }
      cap.n = 0; on_web_message(L"неизвестная\x1f" L"27"); st_check(1, "неизвестная команда не роняет программу");
      /* «Клавиатура сразу у svodik»: выключено — окно открывается, а клавиатура остаётся у игры; включили — сразу у svodik */
      cap.n = 0; on_web_message(L"set\x1f" L"28\x1f" L"captureKeys\x1f" L"0"); st_check(!cfg.captureKeys && wcsstr(wb_str(&cap), L"\"captureKeys\":false"), "команда set: клавиатура не сразу у svodik");
      show_win(); st_check(IsWindowVisible(gWnd) && capture == 0 && !hKb, "окно открылось, клавиатура осталась у игры");
      cap.n = 0; on_web_message(L"set\x1f" L"29\x1f" L"captureKeys\x1f" L"1"); st_check(cfg.captureKeys && (capture == 1 || captureBroken) && wcsstr(wb_str(&cap), L"\"type\":\"capture\""), "включили — клавиатура сразу переходит к svodik");
      hide_win(); t0 = GetTickCount64(); while (GetTickCount64() - t0 < 300) { while (PeekMessageW(&m, NULL, 0, 0, PM_REMOVE)) DispatchMessageW(&m); Sleep(10); }
      /* облегчённый режим и колесо мыши */
      cap.n = 0; on_web_message(L"set\x1f" L"30\x1f" L"lite\x1f" L"1"); st_check(cfg.lite && wcsstr(wb_str(&cap), L"\"lite\":true") && wcsstr(wb_str(&cap), L"\"wheelLines\":"), "команда set: облегчённый режим, шаг колеса из Windows");
      page_sleep(); page_wake(1); st_check(!gAsleep, "сон и пробуждение страницы без движка не роняют программу");
      cap.n = 0; on_web_message(L"set\x1f" L"31\x1f" L"lite\x1f" L"0"); st_check(!cfg.lite, "облегчённый режим выключается");
      cap.n = 0; edit_cmd('Z', 0); edit_cmd('Z', 1); edit_cmd('Y', 0);
      { const wchar_t *c = wb_str(&cap), *u = wcsstr(c, L"\"undo\""), *r1 = u ? wcsstr(u, L"\"redo\"") : NULL, *r2 = r1 ? wcsstr(r1 + 6, L"\"redo\"") : NULL; st_check(u && r1 && r2, "Ctrl+Z — отменить, Ctrl+Shift+Z и Ctrl+Y — вернуть"); }
      gTestCapture = NULL; wb_free(&cap); UnregisterHotKey(gWnd, ID_HOTKEY); tray_remove(); DestroyWindow(gWnd); gWnd = NULL;
    }
  }
  delete_tree(root);
  fprintf(st_out, "ИТОГО: %d из %d, провалов %d\n", st_total - st_fail, st_total, st_fail); fclose(st_out);
  return st_fail;
}
