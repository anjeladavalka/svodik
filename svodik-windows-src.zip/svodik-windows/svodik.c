/*
 * svodik для Windows — законы сервера в окне поверх игры.
 * Окно рисует встроенный в Windows движок WebView2 (тот же Chromium, что в Edge), поэтому программа маленькая
 * и запускается без распаковки. В игру ничего не внедряется. Автор: anjelacold
 *
 * Где что лежит:
 *   рядом с svodik.exe ничего не создаётся — svodik остаётся там, куда его положили;
 *   Документы\svodik\            — документы, картинки тем, settings.json (как и раньше);
 *   Документы\svodik\update\     — скачанное обновление, пока оно не установлено;
 *   %APPDATA%\svodik\            — svodik.ini (окно, клавиша) и журнал svodik.log;
 *   %LOCALAPPDATA%\svodik\       — служебные файлы движка (страница, кэш WebView2).
 */
#include "util.h"
#include <windowsx.h>
#include <shellapi.h>
#include <shobjidl.h>
#include <shlguid.h>
#include <dwmapi.h>
#include <winhttp.h>
#include <objbase.h>
#include "wv2.h"

#define APP_VERSION   L"0.6.1"
#define APP_VERSION_A "0.6.1"
#define APP_LABEL     L"beta 0.61"
#define WND_CLASS     L"svodikOverlayWnd"
#define MUTEX_NAME    L"Local\\svodik-overlay-single"
#define VHOST         L"svodik.example"
#define HELPER_ARG    L"--svodik-finish-update"   /* так старые версии (Electron) запускают новую */

enum { WM_APP_KEY = WM_APP + 1, WM_APP_EDIT, WM_APP_HOT, WM_APP_WHEEL, WM_APP_TRAY, WM_APP_SHOW, WM_APP_DLPROG, WM_APP_DLDONE, WM_APP_DRAG, WM_APP_QUITNOW, WM_APP_CHOOSE, WM_APP_UNINSTALL };
enum { T_FG = 1, T_TOP, T_CUR, T_HIDE, T_QUIT, T_SHOW, T_CLEAN, T_SAVEB, T_SLEEP, T_WAKE };
enum { ID_HOTKEY = 1 };

static HINSTANCE gInst; static HWND gWnd;
static ICoreWebView2Environment *gEnv; static ICoreWebView2Controller2 *gCtl; static ICoreWebView2_3 *gWv;
static wchar_t gExe[MAX_PATH], gRun[MAX_PATH], gAppData[MAX_PATH], gLocal[MAX_PATH], gDocsDefault[MAX_PATH], gIni[MAX_PATH];
static wchar_t gScriptId[128]; static int gNavPending;
static int gPageReady, gShowOnReady, gQuitting, gUninstalling, gJustUpdated, gStartHidden;
static wchar_t gCleanup[MAX_PATH];
static int acrylicOk, isAdmin;
static UINT WM_TASKBARCREATED;
static NOTIFYICONDATAW nid; static int trayAdded;
static wchar_t gUpdLabel[64], gUpdNotified[64];
static int fxOn = 1;
static WBuf *gTestCapture;   /* самопроверка: сюда попадают сообщения для страницы */

/* ---------- настройки окна ---------- */
static struct {
  wchar_t hotkey[64], mode[16], size[4], dataDir[MAX_PATH];
  double alpha; int onTop, autostart, firstRun, gameMode, autoUpdate, hasBounds, cleanedElectron, captureKeys, lite;
  RECT bounds;
} cfg;
static const struct { const wchar_t *k; int w, h; } SIZES[] = { {L"s", 820, 500}, {L"m", 1040, 640}, {L"l", 1280, 780}, {L"xl", 1500, 900} };

static void cfg_defaults(void) {
  wcscpy(cfg.hotkey, L"Alt+Q"); wcscpy(cfg.mode, L"clear"); wcscpy(cfg.size, L"m"); cfg.dataDir[0] = 0;
  cfg.alpha = .97; cfg.onTop = 1; cfg.autostart = 0; cfg.firstRun = 1; cfg.gameMode = 1; cfg.autoUpdate = 1; cfg.hasBounds = 0; cfg.cleanedElectron = 0; cfg.captureKeys = 1; cfg.lite = 0;
}
static void cfg_save(void) {
  WBuf b = {0};
  wb_fmt(&b, L"hotkey=%s\nmode=%s\nsize=%s\nalpha=%.2f\nonTop=%d\nautostart=%d\nfirstRun=%d\ngameMode=%d\nautoUpdate=%d\ncleanedElectron=%d\ncaptureKeys=%d\nlite=%d\n",
         cfg.hotkey, cfg.mode, cfg.size, cfg.alpha, cfg.onTop, cfg.autostart, cfg.firstRun, cfg.gameMode, cfg.autoUpdate, cfg.cleanedElectron, cfg.captureKeys, cfg.lite);
  if (cfg.hasBounds) wb_fmt(&b, L"bounds=%ld,%ld,%ld,%ld\n", cfg.bounds.left, cfg.bounds.top, cfg.bounds.right, cfg.bounds.bottom);
  wb_put(&b, L"dataDir="); wb_put(&b, cfg.dataDir); wb_put(&b, L"\n");
  int len; char *u = w_to_u8(wb_str(&b), (int)b.n, &len);
  write_file_atomic(gIni, u, (size_t)len); free(u); wb_free(&b);
}
static void cfg_set(const wchar_t *k, const wchar_t *v) {
  if (!wcscmp(k, L"hotkey") && *v) wcsncpy(cfg.hotkey, v, 63);
  else if (!wcscmp(k, L"mode") && (!wcscmp(v, L"clear") || !wcscmp(v, L"acrylic"))) wcscpy(cfg.mode, v);
  else if (!wcscmp(k, L"size")) { for (int i = 0; i < 4; i++) if (!wcscmp(v, SIZES[i].k)) wcscpy(cfg.size, v); }
  else if (!wcscmp(k, L"alpha")) { double a = _wtof(v); if (a >= .1 && a <= 1) cfg.alpha = a; }
  else if (!wcscmp(k, L"onTop")) cfg.onTop = _wtoi(v) != 0;
  else if (!wcscmp(k, L"autostart")) cfg.autostart = _wtoi(v) != 0;
  else if (!wcscmp(k, L"firstRun")) cfg.firstRun = _wtoi(v) != 0;
  else if (!wcscmp(k, L"gameMode")) cfg.gameMode = _wtoi(v) != 0;
  else if (!wcscmp(k, L"autoUpdate")) cfg.autoUpdate = _wtoi(v) != 0;
  else if (!wcscmp(k, L"cleanedElectron")) cfg.cleanedElectron = _wtoi(v) != 0;
  else if (!wcscmp(k, L"captureKeys")) cfg.captureKeys = _wtoi(v) != 0;
  else if (!wcscmp(k, L"lite")) cfg.lite = _wtoi(v) != 0;
  else if (!wcscmp(k, L"dataDir")) wcsncpy(cfg.dataDir, v, MAX_PATH - 1);
  else if (!wcscmp(k, L"bounds")) { long a, b, c, d; if (swscanf(v, L"%ld,%ld,%ld,%ld", &a, &b, &c, &d) == 4 && c - a >= 200 && d - b >= 200) { SetRect(&cfg.bounds, a, b, c, d); cfg.hasBounds = 1; } }
}
/* значение поля из overlay.json прежней версии (без полноценного разбора JSON — там простые поля) */
static int json_field(const char *js, const char *key, char *out, int cap) {
  char pat[64]; snprintf(pat, sizeof pat, "\"%s\"", key); const char *p = strstr(js, pat); if (!p) return 0;
  p = strchr(p + strlen(pat), ':'); if (!p) return 0; p++; while (*p == ' ' || *p == '\n' || *p == '\r' || *p == '\t') p++;
  int n = 0;
  if (*p == '"') { p++; while (*p && *p != '"' && n < cap - 1) { if (*p == '\\' && p[1]) p++; out[n++] = *p++; } }
  else while (*p && *p != ',' && *p != '}' && *p != '\n' && n < cap - 1) out[n++] = *p++;
  out[n] = 0; return 1;
}
static void cfg_load(void) {
  cfg_defaults();
  size_t len; char *t = (char *)read_file(gIni, &len);
  if (t) {
    wchar_t *w = u8_to_w(t, (int)len); free(t);
    for (wchar_t *line = wcstok(w, L"\r\n"); line; line = wcstok(NULL, L"\r\n")) { wchar_t *eq = wcschr(line, L'='); if (eq) { *eq = 0; cfg_set(line, eq + 1); } }
    free(w); return;
  }
  /* первый запуск после версии на Electron: переносим клавишу и прочее из overlay.json */
  wchar_t old[MAX_PATH]; path_join(old, gAppData, L"overlay.json");
  char *js = (char *)read_file(old, &len);
  if (js) {
    char v[MAX_PATH * 3]; const char *keys[] = { "hotkey", "mode", "size", "alpha", "onTop", "autostart", "gameMode", "autoUpdate", "dataDir" };
    for (int i = 0; i < 9; i++) if (json_field(js, keys[i], v, sizeof v) && strcmp(v, "null")) {
      wchar_t k[32], *wv = u8_to_w(v, -1); MultiByteToWideChar(CP_UTF8, 0, keys[i], -1, k, 32);
      if (!wcscmp(wv, L"true")) wcscpy(wv, L"1"); else if (!wcscmp(wv, L"false")) wcscpy(wv, L"0");
      cfg_set(k, wv); free(wv);
    }
    cfg.firstRun = 0; free(js); logw(L"настройки перенесены из прежней версии");
  }
}
static const wchar_t *data_dir(void) { return cfg.dataDir[0] && dir_exists(cfg.dataDir) ? cfg.dataDir : gDocsDefault; }

/* ---------- горячая клавиша ---------- */
typedef struct { UINT mods, vk; int ctrl, alt, shift, win; } Accel;
static Accel hot;
static int parse_accel(const wchar_t *acc, Accel *a) {
  memset(a, 0, sizeof *a); wchar_t buf[64]; wcsncpy(buf, acc, 63); buf[63] = 0;
  wchar_t *parts[8]; int n = 0; for (wchar_t *t = wcstok(buf, L"+"); t && n < 8; t = wcstok(NULL, L"+")) parts[n++] = t;
  if (!n) return 0;
  /* «Alt++» не бывает; последний кусок — клавиша */
  for (int i = 0; i < n - 1; i++) {
    if (!wcscmp(parts[i], L"Ctrl") || !wcscmp(parts[i], L"Control") || !wcscmp(parts[i], L"CommandOrControl")) a->ctrl = 1;
    else if (!wcscmp(parts[i], L"Alt")) a->alt = 1; else if (!wcscmp(parts[i], L"Shift")) a->shift = 1; else if (!wcscmp(parts[i], L"Super")) a->win = 1;
  }
  const wchar_t *k = parts[n - 1]; size_t kl = wcslen(k); UINT vk = 0;
  static const struct { const wchar_t *n; UINT vk; } NAMED[] = {
    {L"`", 0xC0}, {L"-", 0xBD}, {L"=", 0xBB}, {L"[", 0xDB}, {L"]", 0xDD}, {L"\\", 0xDC}, {L";", 0xBA}, {L"'", 0xDE}, {L",", 0xBC}, {L".", 0xBE}, {L"/", 0xBF},
    {L"Space", 0x20}, {L"Tab", 0x09}, {L"Insert", 0x2D}, {L"Delete", 0x2E}, {L"Home", 0x24}, {L"End", 0x23}, {L"PageUp", 0x21}, {L"PageDown", 0x22},
    {L"Up", 0x26}, {L"Down", 0x28}, {L"Left", 0x25}, {L"Right", 0x27}, {L"Pause", 0x13}, {L"Scrolllock", 0x91},
    {L"numadd", 0x6B}, {L"numsub", 0x6D}, {L"nummult", 0x6A}, {L"numdiv", 0x6F}, {L"numdec", 0x6E} };
  if (kl == 1 && iswalpha(k[0]) && k[0] < 128) vk = (UINT)towupper(k[0]);
  else if (kl == 1 && k[0] >= L'0' && k[0] <= L'9') vk = 0x30 + (UINT)(k[0] - L'0');
  else if ((k[0] == L'F') && kl >= 2 && kl <= 3 && iswdigit(k[1])) { int f = _wtoi(k + 1); if (f >= 1 && f <= 24) vk = 0x6F + (UINT)f; }
  else if (!wcsncmp(k, L"num", 3) && kl == 4 && iswdigit(k[3])) vk = 0x60 + (UINT)(k[3] - L'0');
  else for (size_t i = 0; i < sizeof NAMED / sizeof NAMED[0]; i++) if (!wcscmp(k, NAMED[i].n)) vk = NAMED[i].vk;
  if (!vk) return 0;
  a->vk = vk; a->mods = (a->ctrl ? MOD_CONTROL : 0) | (a->alt ? MOD_ALT : 0) | (a->shift ? MOD_SHIFT : 0) | (a->win ? MOD_WIN : 0);
  return 1;
}
static int register_hotkey(const wchar_t *acc) {
  UnregisterHotKey(gWnd, ID_HOTKEY); Accel a;
  if (!parse_accel(acc, &a)) return 0;
  if (!RegisterHotKey(gWnd, ID_HOTKEY, a.mods | 0x4000 /* MOD_NOREPEAT */, a.vk)) return 0;
  hot = a; return 1;
}

/* ---------- окно: масштаб, размеры ---------- */
static double scale_of(HWND w) { UINT d = w ? GetDpiForWindow(w) : GetDpiForSystem(); return d ? d / 96.0 : 1.0; }
static RECT default_bounds(void) {
  RECT wa; SystemParametersInfoW(SPI_GETWORKAREA, 0, &wa, 0); double s = scale_of(NULL);
  int w = 1040, h = 640; for (int i = 0; i < 4; i++) if (!wcscmp(cfg.size, SIZES[i].k)) { w = SIZES[i].w; h = SIZES[i].h; }
  w = (int)(w * s); h = (int)(h * s);
  if (w > wa.right - wa.left - 40) w = wa.right - wa.left - 40; if (h > wa.bottom - wa.top - 60) h = wa.bottom - wa.top - 60;
  RECT r = { wa.left + (wa.right - wa.left - w) / 2, wa.top + (int)(40 * s), 0, 0 }; r.right = r.left + w; r.bottom = r.top + h; return r;
}

/* ---------- сообщения странице ---------- */
static void post_json(const wchar_t *json) { if (gTestCapture) { wb_put(gTestCapture, json); wb_putc(gTestCapture, L'\n'); return; } if (gWv) gWv->lpVtbl->PostWebMessageAsJson(gWv, json); }
static void post_type(const wchar_t *type) { WBuf b = {0}; wb_fmt(&b, L"{\"type\":\"%s\"}", type); post_json(wb_str(&b)); wb_free(&b); }
static void reply_raw(int id, const wchar_t *dataJson) { if (!id) return; WBuf b = {0}; wb_fmt(&b, L"{\"type\":\"reply\",\"id\":%d,\"data\":", id); wb_put(&b, dataJson); wb_putc(&b, L'}'); post_json(wb_str(&b)); wb_free(&b); }
static void reply_str(int id, const wchar_t *s) { WBuf b = {0}; wb_jsonz(&b, s); reply_raw(id, wb_str(&b)); wb_free(&b); }

/* ---------- перехват клавиатуры и колеса, пока окно открыто ---------- */
static int capture = -1;   /* 1 — клавиатура у svodik, 0 — окно открыто, клавиатура у игры, -1 — окно скрыто */
static int captureWant, captureBroken, focusMode;
static wchar_t kbdStatus[160] = L"ещё не включался";
static HWND prevFg, gameHwnd;
static HHOOK hKb, hMs; static int mShift, mCtrl, mAlt, mWin, caps; static BYTE heldBefore[256]; static RECT capRect;
typedef struct { UINT vk; wchar_t text[8]; int ctrl, shift, alt; } KeyEv;
typedef struct { int delta, x, y; } WheelEv;
#define GAME() (cfg.gameMode)
static int isShiftVk(DWORD v) { return v == VK_SHIFT || v == VK_LSHIFT || v == VK_RSHIFT; }
static int isCtrlVk(DWORD v) { return v == VK_CONTROL || v == VK_LCONTROL || v == VK_RCONTROL; }
static int isAltVk(DWORD v) { return v == VK_MENU || v == VK_LMENU || v == VK_RMENU; }
static int isWinVk(DWORD v) { return v == VK_LWIN || v == VK_RWIN; }

static LRESULT CALLBACK KbProc(int nCode, WPARAM wParam, LPARAM lParam) {
  if (nCode < 0 || !hKb) return CallNextHookEx(NULL, nCode, wParam, lParam);
  KBDLLHOOKSTRUCT *k = (KBDLLHOOKSTRUCT *)lParam; DWORD vk = k->vkCode & 0xFF;
  if (k->flags & LLKHF_INJECTED) return CallNextHookEx(NULL, nCode, wParam, lParam);       /* чужие искусственные нажатия не трогаем */
  BOOL down = wParam == WM_KEYDOWN || wParam == WM_SYSKEYDOWN, up = wParam == WM_KEYUP || wParam == WM_SYSKEYUP;
  /* сначала запоминаем Shift/Ctrl/Alt — иначе отпущенный Alt от горячей клавиши «залипнет» */
  if (isShiftVk(vk)) mShift = down; else if (isCtrlVk(vk)) mCtrl = down; else if (isAltVk(vk)) mAlt = down; else if (isWinVk(vk)) mWin = down;
  /* клавиши, зажатые до открытия окна (W для бега, Alt и Q от горячей клавиши), отпускаем в игру */
  if (up && heldBefore[vk]) { heldBefore[vk] = 0; return CallNextHookEx(NULL, nCode, wParam, lParam); }
  /* Alt, Win и системные сочетания пропускаем: работают Alt+Tab, Win, Ctrl+Shift+Esc, Print Screen, громкость */
  if (isAltVk(vk) || isWinVk(vk) || mWin || (mAlt && vk == VK_TAB) || (mCtrl && mShift && vk == VK_ESCAPE) || vk == VK_SNAPSHOT || (vk >= 0xAD && vk <= 0xB7))
    return CallNextHookEx(NULL, nCode, wParam, lParam);
  if (down && vk == VK_CAPITAL) caps = !caps;
  if (down && vk == hot.vk && mCtrl == hot.ctrl && mAlt == hot.alt && mShift == hot.shift) { PostMessageW(gWnd, WM_APP_HOT, 0, 0); return 1; }
  if (down && !isShiftVk(vk) && !isCtrlVk(vk)) {
    if (mCtrl && !mAlt && (vk == 'A' || vk == 'C' || vk == 'V' || vk == 'X' || vk == 'Y' || vk == 'Z')) { PostMessageW(gWnd, WM_APP_EDIT, vk, mShift); return 1; }
    KeyEv *e = (KeyEv *)calloc(1, sizeof *e); e->vk = vk; e->ctrl = mCtrl; e->shift = mShift; e->alt = mAlt;
    if (!mCtrl && !mAlt) {
      BYTE st[256] = {0}; if (mShift) { st[VK_SHIFT] = 0x80; st[VK_LSHIFT] = 0x80; } if (caps) st[VK_CAPITAL] = 0x01;
      HWND fg = GetForegroundWindow(); HKL hkl = GetKeyboardLayout(fg ? GetWindowThreadProcessId(fg, NULL) : 0);
      wchar_t out[8] = {0}; int n = ToUnicodeEx(vk, k->scanCode, st, out, 7, 4, hkl);
      int j = 0; for (int i = 0; i < n && i < 7; i++) if (out[i] >= 0x20 && out[i] != 0x7F) e->text[j++] = out[i]; e->text[j] = 0;
    }
    if (!PostMessageW(gWnd, WM_APP_KEY, 0, (LPARAM)e)) free(e);
  }
  return 1;   /* до игры нажатие не доходит */
}
/* колесо мыши над окном svodik: листаем svodik, а не оружие/камеру в игре */
static LRESULT CALLBACK MsProc(int nCode, WPARAM wParam, LPARAM lParam) {
  if (nCode < 0 || wParam != WM_MOUSEWHEEL || !hMs) return CallNextHookEx(NULL, nCode, wParam, lParam);
  MSLLHOOKSTRUCT *m = (MSLLHOOKSTRUCT *)lParam;
  if (!PtInRect(&capRect, m->pt)) return CallNextHookEx(NULL, nCode, wParam, lParam);
  WheelEv *e = (WheelEv *)calloc(1, sizeof *e); e->delta = (short)HIWORD(m->mouseData); e->x = m->pt.x; e->y = m->pt.y;
  if (!PostMessageW(gWnd, WM_APP_WHEEL, 0, (LPARAM)e)) free(e);
  return 1;
}
static int hooks_start(void) {
  if (hKb) return 1;
  memset(heldBefore, 0, sizeof heldBefore);
  for (int v = 0x08; v <= 0xFE; v++) if (GetAsyncKeyState(v) & 0x8000) heldBefore[v] = 1;
  mShift = (GetAsyncKeyState(VK_SHIFT) & 0x8000) != 0; mCtrl = (GetAsyncKeyState(VK_CONTROL) & 0x8000) != 0; mAlt = (GetAsyncKeyState(VK_MENU) & 0x8000) != 0; mWin = 0;
  caps = (GetKeyState(VK_CAPITAL) & 1) != 0;
  GetWindowRect(gWnd, &capRect);
  hKb = SetWindowsHookExW(WH_KEYBOARD_LL, KbProc, gInst, 0);
  if (!hKb) return 0;
  hMs = SetWindowsHookExW(WH_MOUSE_LL, MsProc, gInst, 0);
  return 1;
}
static void hooks_stop(void) { if (hKb) { UnhookWindowsHookEx(hKb); hKb = NULL; } if (hMs) { UnhookWindowsHookEx(hMs); hMs = NULL; } }

static void push_capture(void) {
  WBuf b = {0};
  wb_put(&b, L"{\"type\":\"capture\",\"c\":{\"state\":"); wb_put(&b, capture == 1 ? L"true" : capture == 0 ? L"false" : L"null");
  wb_fmt(&b, L",\"focus\":%s,\"broken\":%s,\"status\":", focusMode ? L"true" : L"false", captureBroken ? L"true" : L"false");
  wb_jsonz(&b, kbdStatus); wb_put(&b, L"}}"); post_json(wb_str(&b)); wb_free(&b);
}
static int win_visible(void) { return gWnd && IsWindowVisible(gWnd); }
static void fail_capture(void) { captureWant = 0; capture = win_visible() ? 0 : -1; push_capture(); }
static void set_capture(int on) {
  if (!GAME()) { capture = -1; return; }
  if (on) {
    captureWant = 1;
    if (!hooks_start()) { _snwprintf(kbdStatus, 159, L"Windows не дал включить перехват (код %lu)", GetLastError()); logw(L"%s", kbdStatus); captureBroken = 1; fail_capture(); return; }
    capture = 1; captureBroken = 0; wcscpy(kbdStatus, L"работает"); push_capture();
  } else { captureWant = 0; hooks_stop(); capture = win_visible() ? 0 : -1; push_capture(); }
}
static void set_noactivate(int on) {
  LONG_PTR ex = GetWindowLongPtrW(gWnd, GWL_EXSTYLE);
  ex = on ? (ex | WS_EX_NOACTIVATE) : (ex & ~WS_EX_NOACTIVATE);
  SetWindowLongPtrW(gWnd, GWL_EXSTYLE, ex); SetWindowPos(gWnd, NULL, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOZORDER | SWP_NOACTIVATE | SWP_FRAMECHANGED);
}
static void focus_webview(void) { if (gCtl) gCtl->lpVtbl->MoveFocus(gCtl, 0); }
/* запасной путь: окно получает фокус как обычное, если перехват не работает или так удобнее */
static void enable_focus_mode(void) {
  if (capture == 1) set_capture(0);
  focusMode = 1; set_noactivate(0);
  ShowWindow(gWnd, SW_SHOW); SetForegroundWindow(gWnd); focus_webview(); push_capture();
}
static void disable_focus_mode(void) { if (!focusMode) return; focusMode = 0; if (GAME()) set_noactivate(1); push_capture(); }
static void refresh_game_hwnd(void) { HWND fg = GetForegroundWindow(); if (fg && fg != gWnd) { prevFg = fg; gameHwnd = fg; } }
static void want_keyboard(void) {
  if (!GAME() || !win_visible() || focusMode || capture == 1 || captureWant) return;
  if (!captureBroken) { refresh_game_hwnd(); set_capture(1); if (capture == 1) return; }
  enable_focus_mode();
}

/* ---------- внешний вид окна: прозрачность и стекло ---------- */
#ifndef DWMWA_USE_IMMERSIVE_DARK_MODE
#define DWMWA_USE_IMMERSIVE_DARK_MODE 20
#endif
static void apply_look(void) {
  BOOL dark = TRUE; DwmSetWindowAttribute(gWnd, DWMWA_USE_IMMERSIVE_DARK_MODE, &dark, sizeof dark);
  int corner = 2 /* скруглённые углы */; DwmSetWindowAttribute(gWnd, 33, &corner, sizeof corner);
  /* «размытие за окном» с пустой областью делает окно по-пиксельно прозрачным: сквозь страницу видна игра */
  HRGN rgn = CreateRectRgn(0, 0, -1, -1); DWM_BLURBEHIND bb = { DWM_BB_ENABLE | DWM_BB_BLURREGION, TRUE, rgn, FALSE };
  DwmEnableBlurBehindWindow(gWnd, &bb); DeleteObject(rgn);
  if (acrylicOk) {
    int acr = !wcscmp(cfg.mode, L"acrylic"), bd = acr ? 3 : 1;
    MARGINS m = { acr ? -1 : 0, acr ? -1 : 0, acr ? -1 : 0, acr ? -1 : 0 }; DwmExtendFrameIntoClientArea(gWnd, &m);
    DwmSetWindowAttribute(gWnd, 38 /* DWMWA_SYSTEMBACKDROP_TYPE */, &bd, sizeof bd);
  }
}
static void apply_top(void) { SetWindowPos(gWnd, cfg.onTop ? HWND_TOPMOST : HWND_NOTOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE); }

/* ---------- облегчённый режим: страница засыпает, пока окно спрятано ---------- */
static int gAsleep;
static void *suspend_handler(void);
static void page_sleep(void) {
  if (!cfg.lite || !gWv || !gCtl || !gPageReady || win_visible() || gQuitting || gUninstalling) return;
  gCtl->lpVtbl->SetIsVisible(gCtl, FALSE);   /* перестаёт рисовать */
  HRESULT hr = gWv->lpVtbl->TrySuspend(gWv, suspend_handler());   /* таймеры и скрипты страницы на паузе, память можно отдать */
  if (SUCCEEDED(hr)) gAsleep = 1; else logw(L"TrySuspend: 0x%08lx", (unsigned long)hr);
  SetTimer(gWnd, T_WAKE, 3 * 3600 * 1000, NULL);   /* раз в три часа ненадолго просыпаемся — проверить обновления */
}
static void page_wake(int visible) {
  if (!gWnd) return;
  KillTimer(gWnd, T_SLEEP); KillTimer(gWnd, T_WAKE);
  if (!gWv || !gCtl) return;
  if (gAsleep) { gWv->lpVtbl->Resume(gWv); gAsleep = 0; }
  if (visible) gCtl->lpVtbl->SetIsVisible(gCtl, TRUE);
}
static void sleep_later(UINT ms) { if (cfg.lite && gWnd) SetTimer(gWnd, T_SLEEP, ms, NULL); }

/* ---------- показать / спрятать ---------- */
static int hidePending;
static void start_timers(void) { SetTimer(gWnd, T_FG, 250, NULL); SetTimer(gWnd, T_TOP, 1500, NULL); if (fxOn) SetTimer(gWnd, T_CUR, 16, NULL); }
static void stop_timers(void) { KillTimer(gWnd, T_FG); KillTimer(gWnd, T_TOP); KillTimer(gWnd, T_CUR); }
static void show_win(void) {
  if (hidePending) { KillTimer(gWnd, T_HIDE); hidePending = 0; }
  page_wake(1);
  if (!gPageReady) { gShowOnReady = 1; return; }
  start_timers(); refresh_game_hwnd();
  if (IsIconic(gWnd)) ShowWindow(gWnd, SW_RESTORE);
  if (GAME()) {
    /* окно появляется поверх, но фокус остаётся у игры — она не сворачивается */
    ShowWindow(gWnd, SW_SHOWNOACTIVATE); apply_top();
    /* «Клавиатура сразу у svodik»: иначе клавиатура остаётся у игры, пока не нажмут на окно */
    if (!captureBroken && cfg.captureKeys) set_capture(1); else { capture = 0; push_capture(); }
  } else { ShowWindow(gWnd, SW_SHOW); apply_top(); SetForegroundWindow(gWnd); focus_webview(); }
  post_type(L"shown");
}
static void hide_win(void) {
  if (!gWnd) return;
  int hadFocus = focusMode || !GAME();
  if (capture == 1 || captureWant) set_capture(0);   /* клавиатура возвращается игре сразу */
  if (win_visible() && !hidePending) { post_type(L"hiding"); hidePending = 1; SetTimer(gWnd, T_HIDE, 120, NULL); }
  disable_focus_mode();
  capture = -1; push_capture();
  /* если окно забирало фокус — возвращаем его игре (и разворачиваем её, если она свернулась) */
  if (hadFocus && prevFg && IsWindow(prevFg)) { if (IsIconic(prevFg)) ShowWindow(prevFg, SW_RESTORE); SetForegroundWindow(prevFg); }
}
static void toggle_win(void) {
  if (!win_visible() || hidePending) { show_win(); return; }
  if (GAME() && !focusMode && capture == 0 && !captureBroken && cfg.captureKeys) { refresh_game_hwnd(); set_capture(1); return; }
  if (!GAME() && GetForegroundWindow() != gWnd) { ShowWindow(gWnd, SW_SHOW); SetForegroundWindow(gWnd); focus_webview(); post_type(L"shown"); return; }
  hide_win();
}

/* ---------- настройки для страницы ---------- */
static void cfg_json(WBuf *b, const wchar_t *error) {
  wb_put(b, L"{\"hotkey\":"); wb_jsonz(b, cfg.hotkey);
  wb_fmt(b, L",\"onTop\":%s,\"mode\":\"%s\",\"alpha\":%.2f,\"size\":\"%s\",\"autostart\":%s,\"gameMode\":%s,\"acrylicOk\":%s,\"admin\":%s,\"win\":true,\"native\":true,\"autoUpdate\":%s",
         cfg.onTop ? L"true" : L"false", cfg.mode, cfg.alpha, cfg.size, cfg.autostart ? L"true" : L"false", cfg.gameMode ? L"true" : L"false",
         acrylicOk ? L"true" : L"false", isAdmin ? L"true" : L"false", cfg.autoUpdate ? L"true" : L"false");
  UINT wl = 3; SystemParametersInfoW(SPI_GETWHEELSCROLLLINES, 0, &wl, 0);
  wb_fmt(b, L",\"captureKeys\":%s,\"lite\":%s,\"wheelLines\":%d", cfg.captureKeys ? L"true" : L"false", cfg.lite ? L"true" : L"false", wl == WHEEL_PAGESCROLL ? -1 : (int)wl);
  wb_put(b, L",\"kbdStatus\":"); wb_jsonz(b, kbdStatus);
  wb_put(b, L",\"dataDir\":"); wb_jsonz(b, data_dir());
  wb_put(b, L",\"version\":\"" APP_VERSION L"\",\"justUpdated\":"); wb_put(b, gJustUpdated ? L"\"" APP_LABEL L"\"" : L"\"\"");
  if (error) { wb_put(b, L",\"error\":"); wb_jsonz(b, error); }
  wb_putc(b, L'}');
}
static void push_cfg(void) { WBuf b = {0}; wb_put(&b, L"{\"type\":\"config\",\"cfg\":"); cfg_json(&b, NULL); wb_putc(&b, L'}'); post_json(wb_str(&b)); wb_free(&b); }

/* ---------- файлы документов (пути только внутри папки svodik) ---------- */
static int rel_ok(const wchar_t *r) {
  /* разрешено: settings.json, documents/<имя>, files/<имя>; имена из букв, цифр, _ . - */
  const wchar_t *slash = wcschr(r, L'/'); const wchar_t *name = r;
  if (slash) {
    size_t dl = (size_t)(slash - r);
    if (!((dl == 9 && !wcsncmp(r, L"documents", 9)) || (dl == 5 && !wcsncmp(r, L"files", 5)))) return 0;
    name = slash + 1; if (wcschr(name, L'/')) return 0;
  } else if (wcscmp(r, L"settings.json") && wcscmp(r, L"documents") && wcscmp(r, L"files")) return 0;
  if (!*name || wcslen(name) > 100 || name[0] == L'.') return 0;
  for (const wchar_t *p = name; *p; p++) if (!(iswalnum(*p) && *p < 128) && *p != L'_' && *p != L'.' && *p != L'-') return 0;
  return 1;
}
static int rel_path(const wchar_t *rel, wchar_t *out) {
  if (!rel_ok(rel)) return 0;
  wchar_t r[128]; wcsncpy(r, rel, 127); r[127] = 0; for (wchar_t *p = r; *p; p++) if (*p == L'/') *p = L'\\';
  path_join(out, data_dir(), r); return 1;
}
static void ensure_data_dirs(void) {
  wchar_t p[MAX_PATH]; ensure_dir(data_dir());
  path_join(p, data_dir(), L"documents"); ensure_dir(p); path_join(p, data_dir(), L"files"); ensure_dir(p);
}
static void fs_docs_all(int id) {
  WBuf b = {0}; wb_putc(&b, L'['); int first = 1;
  wchar_t dir[MAX_PATH], mask[MAX_PATH], p[MAX_PATH]; path_join(dir, data_dir(), L"documents"); path_join(mask, dir, L"*.json");
  WIN32_FIND_DATAW fd; HANDLE f = FindFirstFileW(mask, &fd);
  if (f != INVALID_HANDLE_VALUE) {
    do {
      if (fd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY || !ends_with_i(fd.cFileName, L".json")) continue;
      path_join(p, dir, fd.cFileName); size_t len; char *t = (char *)read_file(p, &len); if (!t) continue;
      int off = (len >= 3 && (unsigned char)t[0] == 0xEF && (unsigned char)t[1] == 0xBB && (unsigned char)t[2] == 0xBF) ? 3 : 0;
      wchar_t *w = u8_to_w(t + off, (int)len - off); free(t);
      if (!first) wb_putc(&b, L','); first = 0; wb_json(&b, w, wcslen(w)); free(w);
    } while (FindNextFileW(f, &fd));
    FindClose(f);
  }
  wb_putc(&b, L']'); reply_raw(id, wb_str(&b)); wb_free(&b);
}
static void fs_list(int id, const wchar_t *rel) {
  WBuf b = {0}; wb_putc(&b, L'['); wchar_t dir[MAX_PATH], mask[MAX_PATH];
  if (rel_path(rel, dir) && !wcschr(rel, L'/')) {
    path_join(mask, dir, L"*"); WIN32_FIND_DATAW fd; HANDLE f = FindFirstFileW(mask, &fd); int first = 1;
    if (f != INVALID_HANDLE_VALUE) {
      do { if (fd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY || ends_with_i(fd.cFileName, L".tmp")) continue; if (!first) wb_putc(&b, L','); first = 0; wb_jsonz(&b, fd.cFileName); } while (FindNextFileW(f, &fd));
      FindClose(f);
    }
  }
  wb_putc(&b, L']'); reply_raw(id, wb_str(&b)); wb_free(&b);
}
static void fs_read(int id, const wchar_t *rel, int asB64) {
  wchar_t p[MAX_PATH]; size_t len; unsigned char *d = rel_path(rel, p) ? read_file(p, &len) : NULL;
  if (!d) { reply_raw(id, L"null"); return; }
  WBuf b = {0};
  if (asB64) { wb_putc(&b, L'"'); wb_b64(&b, d, len); wb_putc(&b, L'"'); }
  else { wchar_t *w = u8_to_w((char *)d, (int)len); wb_json(&b, w, wcslen(w)); free(w); }
  free(d); reply_raw(id, wb_str(&b)); wb_free(&b);
}
static void fs_write(int id, const wchar_t *rel, const wchar_t *b64) {
  wchar_t p[MAX_PATH];
  if (!rel_path(rel, p)) { reply_str(id, L"недопустимое имя файла"); return; }
  ensure_data_dirs();
  size_t len; unsigned char *d = b64_decode(b64, &len);
  BOOL ok = write_file_atomic(p, d, len); free(d);
  if (ok) reply_raw(id, L"true"); else { wchar_t e[96]; _snwprintf(e, 95, L"не удалось записать файл (код %lu)", GetLastError()); e[95] = 0; logw(L"запись %s: %s", rel, e); reply_str(id, e); }
}
static void fs_del(int id, const wchar_t *rel) { wchar_t p[MAX_PATH]; if (rel_path(rel, p) && wcschr(rel, L'/')) DeleteFileW(p); reply_raw(id, L"true"); }

/* ---------- буфер обмена ---------- */
static void clip_set(const wchar_t *t) {
  if (!OpenClipboard(gWnd)) return;
  EmptyClipboard(); size_t n = (wcslen(t) + 1) * sizeof(wchar_t); HGLOBAL g = GlobalAlloc(GMEM_MOVEABLE, n);
  if (g) { memcpy(GlobalLock(g), t, n); GlobalUnlock(g); if (!SetClipboardData(CF_UNICODETEXT, g)) GlobalFree(g); }
  CloseClipboard();
}
static void clip_get(wchar_t **text, wchar_t **html) {
  *text = NULL; *html = NULL; if (!OpenClipboard(gWnd)) return;
  HANDLE h = GetClipboardData(CF_UNICODETEXT);
  if (h) { const wchar_t *p = (const wchar_t *)GlobalLock(h); if (p) { *text = _wcsdup(p); GlobalUnlock(h); } }
  UINT fmt = RegisterClipboardFormatW(L"HTML Format"); h = fmt ? GetClipboardData(fmt) : NULL;
  if (h) {
    const char *p = (const char *)GlobalLock(h); SIZE_T sz = GlobalSize(h);
    if (p && sz) {
      char *c = (char *)malloc(sz + 1); memcpy(c, p, sz); c[sz] = 0;
      const char *sh = strstr(c, "StartHTML:"), *eh = strstr(c, "EndHTML:"); long s = sh ? atol(sh + 10) : 0, e = eh ? atol(eh + 8) : 0;
      if (s > 0 && e > s && (SIZE_T)e <= sz) *html = u8_to_w(c + s, (int)(e - s));
      else { const char *lt = strchr(c, '<'); if (lt) *html = u8_to_w(lt, -1); }
      free(c);
    }
    if (p) GlobalUnlock(h);
  }
  CloseClipboard();
}
static void edit_cmd(UINT letter, int shift) {
  const wchar_t *cmd = letter == 'A' ? L"selectAll" : letter == 'C' ? L"copy" : letter == 'V' ? L"paste" : letter == 'X' ? L"cut" : (letter == 'Y' || shift) ? L"redo" : L"undo";
  WBuf b = {0}; wb_fmt(&b, L"{\"type\":\"edit\",\"d\":{\"cmd\":\"%s\"", cmd);
  if (letter == 'V') { wchar_t *t, *h; clip_get(&t, &h); wb_put(&b, L",\"text\":"); wb_jsonz(&b, t ? t : L""); wb_put(&b, L",\"html\":"); wb_jsonz(&b, h ? h : L""); free(t); free(h); }
  wb_put(&b, L"}}"); post_json(wb_str(&b)); wb_free(&b);
}

/* ---------- значок у часов ---------- */
static void tray_add(void) {
  memset(&nid, 0, sizeof nid); nid.cbSize = sizeof nid; nid.hWnd = gWnd; nid.uID = 1; nid.uFlags = NIF_ICON | NIF_MESSAGE | NIF_TIP;
  nid.uCallbackMessage = WM_APP_TRAY; nid.hIcon = (HICON)LoadImageW(gInst, MAKEINTRESOURCEW(1), IMAGE_ICON, GetSystemMetrics(SM_CXSMICON), GetSystemMetrics(SM_CYSMICON), 0);
  _snwprintf(nid.szTip, 127, L"svodik — %s", cfg.hotkey);
  trayAdded = Shell_NotifyIconW(NIM_ADD, &nid);
}
static void tray_tip(void) { if (!trayAdded) return; nid.uFlags = NIF_TIP; _snwprintf(nid.szTip, 127, L"svodik — %s", cfg.hotkey); Shell_NotifyIconW(NIM_MODIFY, &nid); }
static void tray_balloon(const wchar_t *title, const wchar_t *text) {
  if (!trayAdded) return;
  nid.uFlags = NIF_INFO; nid.dwInfoFlags = NIIF_INFO; wcsncpy(nid.szInfoTitle, title, 63); nid.szInfoTitle[63] = 0; wcsncpy(nid.szInfo, text, 255); nid.szInfo[255] = 0;
  Shell_NotifyIconW(NIM_MODIFY, &nid);
}
static void tray_remove(void) { if (trayAdded) { Shell_NotifyIconW(NIM_DELETE, &nid); trayAdded = 0; } }
static void quit_app(void);
static void open_data_dir(void) { ensure_data_dirs(); ShellExecuteW(NULL, L"open", data_dir(), NULL, NULL, SW_SHOWNORMAL); }
static void apply_size(const wchar_t *k) {
  for (int i = 0; i < 4; i++) if (!wcscmp(k, SIZES[i].k)) {
    wcscpy(cfg.size, k); double s = scale_of(gWnd); RECT r; GetWindowRect(gWnd, &r);
    int w = (int)(SIZES[i].w * s), h = (int)(SIZES[i].h * s);
    SetWindowPos(gWnd, NULL, r.left + ((r.right - r.left) - w) / 2, r.top, w, h, SWP_NOZORDER | SWP_NOACTIVATE);
  }
}
static void tray_menu(void) {
  HMENU m = CreatePopupMenu(), sz = CreatePopupMenu(); wchar_t t[128];
  _snwprintf(t, 127, L"Показать / скрыть\t%s", cfg.hotkey); AppendMenuW(m, MF_STRING, 1, t);
  AppendMenuW(m, MF_STRING | (cfg.onTop ? MF_CHECKED : 0), 2, L"Поверх всех окон");
  const wchar_t *names[] = { L"Маленькое", L"Среднее", L"Большое", L"Очень большое" };
  for (int i = 0; i < 4; i++) AppendMenuW(sz, MF_STRING | (!wcscmp(cfg.size, SIZES[i].k) ? MF_CHECKED : 0), 11 + i, names[i]);
  AppendMenuW(m, MF_POPUP, (UINT_PTR)sz, L"Размер окна");
  AppendMenuW(m, MF_STRING, 3, L"Вернуть окно на место");
  AppendMenuW(m, MF_STRING, 4, L"Открыть папку с документами");
  if (gUpdLabel[0]) { _snwprintf(t, 127, L"⬆ Обновить до %s", gUpdLabel); AppendMenuW(m, MF_STRING, 5, t); }
  AppendMenuW(m, MF_SEPARATOR, 0, NULL); AppendMenuW(m, MF_STRING, 9, L"Выход");
  POINT p; GetCursorPos(&p); SetForegroundWindow(gWnd);
  int cmd = TrackPopupMenu(m, TPM_RETURNCMD | TPM_RIGHTBUTTON | TPM_NONOTIFY, p.x, p.y, 0, gWnd, NULL);
  DestroyMenu(m); PostMessageW(gWnd, WM_NULL, 0, 0);
  if (cmd == 1) toggle_win();
  else if (cmd == 2) { cfg.onTop = !cfg.onTop; cfg_save(); apply_top(); push_cfg(); }
  else if (cmd >= 11 && cmd <= 14) { apply_size(SIZES[cmd - 11].k); cfg_save(); push_cfg(); }
  else if (cmd == 3) { cfg.hasBounds = 0; cfg_save(); RECT r = default_bounds(); SetWindowPos(gWnd, NULL, r.left, r.top, r.right - r.left, r.bottom - r.top, SWP_NOZORDER | SWP_NOACTIVATE); show_win(); }
  else if (cmd == 4) open_data_dir();
  else if (cmd == 5) { show_win(); post_type(L"openUpdate"); }
  else if (cmd == 9) quit_app();
}

/* ---------- запуск служебных команд Windows без окна ---------- */
static DWORD run_hidden(wchar_t *cmdline, DWORD waitMs, const wchar_t *envBlock) {
  STARTUPINFOW si = { sizeof si }; PROCESS_INFORMATION pi; DWORD code = (DWORD)-1;
  if (!CreateProcessW(NULL, cmdline, NULL, NULL, FALSE, CREATE_NO_WINDOW | (envBlock ? CREATE_UNICODE_ENVIRONMENT : 0), (LPVOID)envBlock, NULL, &si, &pi)) return (DWORD)-2;
  if (waitMs) { WaitForSingleObject(pi.hProcess, waitMs); GetExitCodeProcess(pi.hProcess, &code); } else code = 0;
  CloseHandle(pi.hThread); CloseHandle(pi.hProcess); return code;
}
/* автозапуск через Планировщик заданий — так svodik стартует сразу с правами администратора */
static const wchar_t *set_autostart(int on) {
  wchar_t cmd[MAX_PATH * 2 + 128];
  if (on) _snwprintf(cmd, MAX_PATH * 2 + 127, L"schtasks.exe /Create /TN svodik /TR \"\\\"%s\\\" --hidden\" /SC ONLOGON /RL HIGHEST /F", gExe);
  else wcscpy(cmd, L"schtasks.exe /Delete /TN svodik /F");
  DWORD r = run_hidden(cmd, 15000, NULL);
  logw(L"автозапуск %s: код %ld", on ? L"вкл" : L"выкл", (long)r);
  if (on && r != 0) return L"Не удалось создать задачу автозапуска.";
  cfg.autostart = on; cfg_save(); return NULL;
}

/* ---------- страница и скрипт запуска ---------- */
static void *res_data(int id, DWORD *size) {
  HRSRC r = FindResourceW(gInst, MAKEINTRESOURCEW(id), (LPCWSTR)RT_RCDATA); if (!r) return NULL;
  HGLOBAL g = LoadResource(gInst, r); *size = SizeofResource(gInst, r); return g ? LockResource(g) : NULL;
}
static void build_init_script(WBuf *b) {
  wchar_t sp[MAX_PATH]; path_join(sp, data_dir(), L"settings.json"); size_t len; char *st = (char *)read_file(sp, &len);
  wb_put(b, L"window.__SVK_INIT={\"config\":"); cfg_json(b, NULL);
  wb_put(b, L",\"settings\":"); if (st) { wchar_t *w = u8_to_w(st, (int)len); wb_json(b, w, wcslen(w)); free(w); free(st); } else wb_put(b, L"null");
  wb_put(b, L",\"version\":\"" APP_VERSION L"\"};\n");
  DWORD sz; const char *shim = (const char *)res_data(102, &sz);
  if (shim) { wchar_t *w = u8_to_w(shim, (int)sz); wb_put(b, w); free(w); }
}
static void write_page(void) {
  wchar_t dir[MAX_PATH], p[MAX_PATH]; path_join(dir, gLocal, L"app"); ensure_dir(dir); path_join(p, dir, L"index.html");
  DWORD sz; const void *html = res_data(101, &sz); if (!html) return;
  size_t have; unsigned char *cur = read_file(p, &have);
  if (!cur || have != sz || memcmp(cur, html, sz)) write_file_atomic(p, html, sz);
  free(cur);
}

/* ---------- WebView2: обработчики ---------- */
typedef struct Handler { const void *lpVtbl; LONG ref; const GUID *iid; } Handler;
static HRESULT STDMETHODCALLTYPE H_QI(Handler *This, REFIID riid, void **ppv) {
  if (IsEqualIID(riid, &IID_IUnknown) || IsEqualIID(riid, This->iid)) { *ppv = This; InterlockedIncrement(&This->ref); return S_OK; }
  *ppv = NULL; return E_NOINTERFACE;
}
static ULONG STDMETHODCALLTYPE H_AddRef(Handler *This) { return (ULONG)InterlockedIncrement(&This->ref); }
static ULONG STDMETHODCALLTYPE H_Release(Handler *This) { return (ULONG)InterlockedDecrement(&This->ref); }   /* объекты статические */
typedef struct { void *QI, *AddRef, *Release, *Invoke; } HVtbl;
#define HANDLER(name, fn, iid) static const HVtbl vt_##name = { (void *)H_QI, (void *)H_AddRef, (void *)H_Release, (void *)fn }; static Handler h_##name = { &vt_##name, 1, &iid };

static void on_web_message(const wchar_t *msg);
static void navigate_page(void);
static void fatal_webview(HRESULT hr, const wchar_t *where);

static HRESULT STDMETHODCALLTYPE OnMessage(Handler *This, void *sender, ICoreWebView2WebMessageReceivedEventArgs *a) {
  (void)This; (void)sender; LPWSTR s = NULL;
  if (SUCCEEDED(a->lpVtbl->TryGetWebMessageAsString(a, &s)) && s) { on_web_message(s); CoTaskMemFree(s); }
  return S_OK;
}
static int is_http(const wchar_t *u) { return starts_with_i(u, L"https://") || starts_with_i(u, L"http://"); }
static HRESULT STDMETHODCALLTYPE OnNewWindow(Handler *This, void *sender, ICoreWebView2NewWindowRequestedEventArgs *a) {
  (void)This; (void)sender; LPWSTR u = NULL;
  if (SUCCEEDED(a->lpVtbl->Uri(a, &u)) && u) { if (is_http(u)) ShellExecuteW(NULL, L"open", u, NULL, NULL, SW_SHOWNORMAL); CoTaskMemFree(u); }
  a->lpVtbl->SetHandled(a, TRUE); return S_OK;
}
static HRESULT STDMETHODCALLTYPE OnNavStart(Handler *This, void *sender, ICoreWebView2NavigationStartingEventArgs *a) {
  (void)This; (void)sender; LPWSTR u = NULL;
  if (SUCCEEDED(a->lpVtbl->Uri(a, &u)) && u) {
    /* внутри окна открывается только сама страница svodik; ссылки — в обычном браузере */
    if (!starts_with_i(u, L"https://" VHOST L"/") && !starts_with_i(u, L"about:") && !starts_with_i(u, L"data:")) {
      a->lpVtbl->SetCancel(a, TRUE); if (is_http(u)) ShellExecuteW(NULL, L"open", u, NULL, NULL, SW_SHOWNORMAL);
    }
    CoTaskMemFree(u);
  }
  return S_OK;
}
static HRESULT STDMETHODCALLTYPE OnProcessFailed(Handler *This, void *sender, ICoreWebView2ProcessFailedEventArgs *a) {
  (void)This; (void)sender; int kind = -1; a->lpVtbl->ProcessFailedKind(a, &kind); logw(L"движок WebView2: сбой процесса, вид %d", kind);
  if (kind == 1 /* страница */ && gWv) gWv->lpVtbl->Reload(gWv);
  return S_OK;
}
static HRESULT STDMETHODCALLTYPE OnScriptAdded(Handler *This, HRESULT hr, LPCWSTR id) {
  (void)This; if (SUCCEEDED(hr) && id) { wcsncpy(gScriptId, id, 127); gScriptId[127] = 0; }
  else logw(L"скрипт запуска не добавлен: 0x%08lx", (unsigned long)hr);
  if (gNavPending) { gNavPending = 0; gWv->lpVtbl->Navigate(gWv, L"https://" VHOST L"/index.html"); }
  return S_OK;
}
HANDLER(msg, OnMessage, IID_ICoreWebView2WebMessageReceivedEventHandler)
HANDLER(newwin, OnNewWindow, IID_ICoreWebView2NewWindowRequestedEventHandler)
HANDLER(navstart, OnNavStart, IID_ICoreWebView2NavigationStartingEventHandler)
HANDLER(pfail, OnProcessFailed, IID_ICoreWebView2ProcessFailedEventHandler)
HANDLER(script, OnScriptAdded, IID_ICoreWebView2AddScriptToExecuteOnDocumentCreatedCompletedHandler)
static HRESULT STDMETHODCALLTYPE OnSuspended(Handler *This, HRESULT hr, BOOL ok) { (void)This; if (FAILED(hr) || !ok) gAsleep = 0; return S_OK; }
HANDLER(suspend, OnSuspended, IID_ICoreWebView2TrySuspendCompletedHandler)
static void *suspend_handler(void) { return &h_suspend; }

/* загрузить страницу заново с новым скриптом запуска (например, после смены папки документов) */
static void navigate_page(void) {
  if (!gWv) return;
  if (gScriptId[0]) { gWv->lpVtbl->RemoveScriptToExecuteOnDocumentCreated(gWv, gScriptId); gScriptId[0] = 0; }
  WBuf b = {0}; build_init_script(&b); gNavPending = 1;
  HRESULT hr = gWv->lpVtbl->AddScriptToExecuteOnDocumentCreated(gWv, wb_str(&b), &h_script);
  wb_free(&b);
  if (FAILED(hr)) { logw(L"AddScript: 0x%08lx", (unsigned long)hr); gNavPending = 0; gWv->lpVtbl->Navigate(gWv, L"https://" VHOST L"/index.html"); }
}
static void resize_webview(void) { if (!gCtl) return; RECT r; GetClientRect(gWnd, &r); gCtl->lpVtbl->SetBounds(gCtl, r); }

static HRESULT STDMETHODCALLTYPE OnController(Handler *This, HRESULT hr, ICoreWebView2Controller2 *ctl) {
  (void)This;
  if (FAILED(hr) || !ctl) { fatal_webview(hr, L"окно движка"); return S_OK; }
  if (FAILED(ctl->lpVtbl->QueryInterface(ctl, &IID_ICoreWebView2Controller2, (void **)&gCtl))) { fatal_webview(E_NOINTERFACE, L"Controller2"); return S_OK; }
  COREWEBVIEW2_COLOR clear = { 0, 0, 0, 0 }; gCtl->lpVtbl->SetDefaultBackgroundColor(gCtl, clear);
  void *wv0 = NULL; gCtl->lpVtbl->CoreWebView2(gCtl, &wv0);
  if (!wv0 || FAILED(((IUnknown *)wv0)->lpVtbl->QueryInterface((IUnknown *)wv0, &IID_ICoreWebView2_3, (void **)&gWv))) { fatal_webview(E_NOINTERFACE, L"WebView2 слишком старый"); return S_OK; }
  ((IUnknown *)wv0)->lpVtbl->Release((IUnknown *)wv0);
  ICoreWebView2Settings *st = NULL;
  if (SUCCEEDED(gWv->lpVtbl->Settings(gWv, (void **)&st)) && st) {
    st->lpVtbl->SetIsStatusBarEnabled(st, FALSE); st->lpVtbl->SetIsZoomControlEnabled(st, FALSE);
    st->lpVtbl->SetAreDefaultContextMenusEnabled(st, FALSE); st->lpVtbl->SetIsBuiltInErrorPageEnabled(st, FALSE);
    wchar_t dev[8]; st->lpVtbl->SetAreDevToolsEnabled(st, GetEnvironmentVariableW(L"SVODIK_DEVTOOLS", dev, 8) ? TRUE : FALSE);
    st->lpVtbl->Release(st);
  }
  EventRegistrationToken t;
  gWv->lpVtbl->add_WebMessageReceived(gWv, &h_msg, &t);
  gWv->lpVtbl->add_NewWindowRequested(gWv, &h_newwin, &t);
  gWv->lpVtbl->add_NavigationStarting(gWv, &h_navstart, &t);
  gWv->lpVtbl->add_ProcessFailed(gWv, &h_pfail, &t);
  wchar_t dir[MAX_PATH]; path_join(dir, gLocal, L"app");
  gWv->lpVtbl->SetVirtualHostNameToFolderMapping(gWv, VHOST, dir, 1 /* разрешить */);
  resize_webview(); gCtl->lpVtbl->SetIsVisible(gCtl, TRUE);
  navigate_page();
  return S_OK;
}
HANDLER(ctl, OnController, IID_ICoreWebView2CreateCoreWebView2ControllerCompletedHandler)
static HRESULT STDMETHODCALLTYPE OnEnvironment(Handler *This, HRESULT hr, ICoreWebView2Environment *env) {
  (void)This;
  if (FAILED(hr) || !env) { fatal_webview(hr, L"движок"); return S_OK; }
  gEnv = env; env->lpVtbl->AddRef(env);
  hr = env->lpVtbl->CreateCoreWebView2Controller(env, gWnd, &h_ctl);
  if (FAILED(hr)) fatal_webview(hr, L"окно движка");
  return S_OK;
}
HANDLER(env, OnEnvironment, IID_ICoreWebView2CreateCoreWebView2EnvironmentCompletedHandler)

typedef HRESULT (STDAPICALLTYPE *PFN_CreateEnv)(PCWSTR, PCWSTR, void *, void *);
typedef HRESULT (STDAPICALLTYPE *PFN_GetVer)(PCWSTR, LPWSTR *);
static void fatal_webview(HRESULT hr, const wchar_t *where) {
  logw(L"WebView2 (%s): 0x%08lx", where, (unsigned long)hr);
  wchar_t m[512]; _snwprintf(m, 511, L"svodik не смог запустить встроенный движок Windows (WebView2): %s, код 0x%08lx.\n\n"
    L"Обычно помогает установить или обновить «Microsoft Edge WebView2 Runtime». Открыть страницу загрузки?", where, (unsigned long)hr);
  if (MessageBoxW(NULL, m, L"svodik", MB_ICONWARNING | MB_YESNO) == IDYES) ShellExecuteW(NULL, L"open", L"https://go.microsoft.com/fwlink/p/?LinkId=2124703", NULL, NULL, SW_SHOWNORMAL);
  gQuitting = 1; PostQuitMessage(1);
}
static void start_webview(void) {
  /* загрузчик WebView2 лежит внутри svodik.exe; при первом запуске кладём его рядом со служебными файлами */
  wchar_t dll[MAX_PATH], udf[MAX_PATH]; ensure_dir(gLocal); path_join(dll, gLocal, L"WebView2Loader.dll"); path_join(udf, gLocal, L"webview");
  DWORD sz; const void *bin = res_data(103, &sz); size_t have = 0; unsigned char *cur = read_file(dll, &have);
  if (bin && (!cur || have != sz || memcmp(cur, bin, sz))) write_file_atomic(dll, bin, sz);
  free(cur);
  HMODULE m = LoadLibraryW(dll);
  PFN_CreateEnv create = m ? (PFN_CreateEnv)(void *)GetProcAddress(m, "CreateCoreWebView2EnvironmentWithOptions") : NULL;
  PFN_GetVer getver = m ? (PFN_GetVer)(void *)GetProcAddress(m, "GetAvailableCoreWebView2BrowserVersionString") : NULL;
  if (!create) { fatal_webview(HRESULT_FROM_WIN32(GetLastError()), L"загрузчик"); return; }
  LPWSTR ver = NULL;
  if (getver && (FAILED(getver(NULL, &ver)) || !ver)) { fatal_webview(HRESULT_FROM_WIN32(ERROR_FILE_NOT_FOUND), L"не установлен"); return; }
  logw(L"WebView2 %s", ver ? ver : L"?"); if (ver) CoTaskMemFree(ver);
  write_page();
  SetEnvironmentVariableW(L"WEBVIEW2_DEFAULT_BACKGROUND_COLOR", L"00000000");
  HRESULT hr = create(NULL, udf, NULL, &h_env);
  if (FAILED(hr)) fatal_webview(hr, L"движок");
}

/* ---------- обновление: загрузка ---------- */
typedef struct { wchar_t url[2048], tag[64]; long long size; } DlJob;
typedef struct { long long got, total; } DlProg;
typedef struct { int ok; wchar_t file[MAX_PATH], error[256]; } DlDone;
static volatile LONG dlBusy;
static void dl_fail(DlDone *d, const wchar_t *fmt, DWORD code) { d->ok = 0; _snwprintf(d->error, 255, fmt, code); }
static DWORD WINAPI dl_thread(LPVOID p) {
  DlJob *j = (DlJob *)p; DlDone *d = (DlDone *)calloc(1, sizeof *d);
  HINTERNET ses = NULL, con = NULL, req = NULL; HANDLE f = INVALID_HANDLE_VALUE;
  wchar_t dir[MAX_PATH], part[MAX_PATH], safe[64]; int k = 0;
  for (const wchar_t *s = j->tag; *s && k < 40; s++) if ((iswalnum(*s) && *s < 128) || *s == L'.' || *s == L'-' || *s == L'_') safe[k++] = *s; safe[k] = 0;
  path_join(dir, data_dir(), L"update"); ensure_dir(dir);
  _snwprintf(d->file, MAX_PATH - 1, L"%s\\svodik-update-%s.exe", dir, k ? safe : L"new"); _snwprintf(part, MAX_PATH - 1, L"%s.part", d->file);
  URL_COMPONENTSW uc = { sizeof uc }; wchar_t host[256], path[2048]; uc.lpszHostName = host; uc.dwHostNameLength = 255; uc.lpszUrlPath = path; uc.dwUrlPathLength = 2047;
  wchar_t extra[1024]; uc.lpszExtraInfo = extra; uc.dwExtraInfoLength = 1023;
  if (!WinHttpCrackUrl(j->url, 0, 0, &uc)) { dl_fail(d, L"неверная ссылка (%lu)", GetLastError()); goto done; }
  wcsncat(path, extra, 2047 - wcslen(path));
  ses = WinHttpOpen(L"svodik/" APP_VERSION, WINHTTP_ACCESS_TYPE_AUTOMATIC_PROXY, WINHTTP_NO_PROXY_NAME, WINHTTP_NO_PROXY_BYPASS, 0);
  if (!ses) ses = WinHttpOpen(L"svodik/" APP_VERSION, WINHTTP_ACCESS_TYPE_DEFAULT_PROXY, WINHTTP_NO_PROXY_NAME, WINHTTP_NO_PROXY_BYPASS, 0);
  if (!ses) { dl_fail(d, L"нет связи (%lu)", GetLastError()); goto done; }
  WinHttpSetTimeouts(ses, 15000, 15000, 30000, 60000);
  con = WinHttpConnect(ses, host, uc.nPort, 0); if (!con) { dl_fail(d, L"нет связи (%lu)", GetLastError()); goto done; }
  req = WinHttpOpenRequest(con, L"GET", path, NULL, WINHTTP_NO_REFERER, WINHTTP_DEFAULT_ACCEPT_TYPES, uc.nScheme == INTERNET_SCHEME_HTTPS ? WINHTTP_FLAG_SECURE : 0);
  if (!req || !WinHttpSendRequest(req, WINHTTP_NO_ADDITIONAL_HEADERS, 0, WINHTTP_NO_REQUEST_DATA, 0, 0, 0) || !WinHttpReceiveResponse(req, NULL)) { dl_fail(d, L"связь оборвалась — попробуйте ещё раз (%lu)", GetLastError()); goto done; }
  DWORD status = 0, sl = sizeof status; WinHttpQueryHeaders(req, WINHTTP_QUERY_STATUS_CODE | WINHTTP_QUERY_FLAG_NUMBER, NULL, &status, &sl, NULL);
  if (status != 200) { dl_fail(d, L"файл не скачался (ответ %lu)", status); goto done; }
  long long total = j->size; if (!total) { wchar_t cl[32]; DWORD cls = sizeof cl; if (WinHttpQueryHeaders(req, WINHTTP_QUERY_CONTENT_LENGTH, NULL, cl, &cls, NULL)) total = _wtoi64(cl); }
  f = CreateFileW(part, GENERIC_WRITE, 0, NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
  if (f == INVALID_HANDLE_VALUE) { dl_fail(d, L"нет прав на запись в папку обновлений (%lu)", GetLastError()); goto done; }
  static char buf[1 << 16]; long long got = 0; DWORD n = 0, w; ULONGLONG last = 0; char head[2] = {0};
  for (;;) {
    if (!WinHttpReadData(req, buf, sizeof buf, &n)) { dl_fail(d, L"связь оборвалась — попробуйте ещё раз (%lu)", GetLastError()); goto done; }
    if (!n) break;
    if (!got) { head[0] = buf[0]; head[1] = n > 1 ? buf[1] : 0; }
    if (!WriteFile(f, buf, n, &w, NULL) || w != n) { dl_fail(d, L"не удалось записать файл (%lu)", GetLastError()); goto done; }
    got += n; ULONGLONG now = GetTickCount64();
    if (now - last > 150) { last = now; DlProg *pr = (DlProg *)malloc(sizeof *pr); pr->got = got; pr->total = total; if (!PostMessageW(gWnd, WM_APP_DLPROG, 0, (LPARAM)pr)) free(pr); }
  }
  CloseHandle(f); f = INVALID_HANDLE_VALUE;
  if (total && got != total) { dl_fail(d, L"файл скачался не полностью", 0); goto done; }
  if (head[0] != 'M' || head[1] != 'Z') { dl_fail(d, L"скачался не тот файл", 0); goto done; }
  DeleteFileW(d->file);
  if (!MoveFileExW(part, d->file, MOVEFILE_REPLACE_EXISTING)) { dl_fail(d, L"не удалось сохранить файл (%lu)", GetLastError()); goto done; }
  d->ok = 1; logw(L"обновление скачано: %s", d->file);
done:
  if (f != INVALID_HANDLE_VALUE) CloseHandle(f);
  if (!d->ok) { DeleteFileW(part); logw(L"загрузка обновления: %s", d->error); }
  if (req) WinHttpCloseHandle(req); if (con) WinHttpCloseHandle(con); if (ses) WinHttpCloseHandle(ses);
  free(j); InterlockedExchange(&dlBusy, 0);
  if (!PostMessageW(gWnd, WM_APP_DLDONE, 0, (LPARAM)d)) free(d);
  return 0;
}

/* ---------- обновление: установка на то же место ----------
 * Работающий svodik.exe нельзя перезаписать, но можно переименовать. Поэтому: svodik.exe → svodik.exe.old,
 * новый файл встаёт на место svodik.exe, запускается и после нашего закрытия удаляет .old. */
static const wchar_t *install_update(const wchar_t *file) {
  static wchar_t err[256]; wchar_t dir[MAX_PATH], old[MAX_PATH + 8]; path_join(dir, data_dir(), L"update");
  if (!starts_with_i(file, dir) || !file_exists(file)) return L"файл обновления не найден";
  _snwprintf(old, MAX_PATH + 7, L"%s.old", gRun);
  DeleteFileW(old);
  if (!MoveFileExW(gRun, old, MOVEFILE_REPLACE_EXISTING)) { _snwprintf(err, 255, L"не удалось освободить место для новой версии (код %lu)", GetLastError()); return err; }
  if (!MoveFileExW(file, gExe, MOVEFILE_COPY_ALLOWED | MOVEFILE_REPLACE_EXISTING | MOVEFILE_WRITE_THROUGH)) {
    DWORD e = GetLastError(); MoveFileExW(old, gRun, MOVEFILE_REPLACE_EXISTING);
    _snwprintf(err, 255, L"не удалось поставить новую версию (код %lu)", e); return err;
  }
  wchar_t cmd[MAX_PATH * 3]; _snwprintf(cmd, MAX_PATH * 3 - 1, L"\"%s\" --after-update %lu --cleanup \"%s\"", gExe, GetCurrentProcessId(), old);
  wchar_t cwd[MAX_PATH]; wcscpy(cwd, gExe); *(wchar_t *)base_name(cwd) = 0;
  STARTUPINFOW si = { sizeof si }; PROCESS_INFORMATION pi;
  if (!CreateProcessW(gExe, cmd, NULL, NULL, FALSE, 0, NULL, cwd, &si, &pi)) {
    DWORD e = GetLastError(); MoveFileExW(gExe, file, MOVEFILE_COPY_ALLOWED | MOVEFILE_REPLACE_EXISTING); MoveFileExW(old, gRun, MOVEFILE_REPLACE_EXISTING);
    _snwprintf(err, 255, L"не удалось запустить новую версию (код %lu)", e); return err;
  }
  CloseHandle(pi.hThread); CloseHandle(pi.hProcess);
  logw(L"обновление установлено в %s, перезапуск", gExe);
  return NULL;
}

/* ---------- удаление svodik ---------- */
/* один и тот же файл, даже если путь записан по-разному (короткие имена, регистр, другой вид диска) */
static int same_file(const wchar_t *a, const wchar_t *b) {
  if (!_wcsicmp(a, b)) return 1;
  HANDLE x = CreateFileW(a, 0, FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE, NULL, OPEN_EXISTING, 0, NULL); if (x == INVALID_HANDLE_VALUE) return 0;
  HANDLE y = CreateFileW(b, 0, FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE, NULL, OPEN_EXISTING, 0, NULL); if (y == INVALID_HANDLE_VALUE) { CloseHandle(x); return 0; }
  BY_HANDLE_FILE_INFORMATION i1, i2; int r = GetFileInformationByHandle(x, &i1) && GetFileInformationByHandle(y, &i2) &&
    i1.dwVolumeSerialNumber == i2.dwVolumeSerialNumber && i1.nFileIndexHigh == i2.nFileIndexHigh && i1.nFileIndexLow == i2.nFileIndexLow;
  CloseHandle(x); CloseHandle(y); return r;
}
/* ярлыки на рабочем столе и в «Пуске», которые ведут на этот svodik.exe */
static void remove_shortcuts_in(const wchar_t *dir, int depth) {
  wchar_t mask[MAX_PATH], p[MAX_PATH]; WIN32_FIND_DATAW fd; path_join(mask, dir, L"*");
  HANDLE f = FindFirstFileW(mask, &fd); if (f == INVALID_HANDLE_VALUE) return;
  do {
    if (!wcscmp(fd.cFileName, L".") || !wcscmp(fd.cFileName, L"..")) continue;
    path_join(p, dir, fd.cFileName);
    if (fd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) { if (depth > 0) remove_shortcuts_in(p, depth - 1); continue; }
    if (!ends_with_i(fd.cFileName, L".lnk")) continue;
    IShellLinkW *sl = NULL; IPersistFile *pf = NULL; wchar_t target[MAX_PATH] = {0};
    if (SUCCEEDED(CoCreateInstance(&CLSID_ShellLink, NULL, CLSCTX_INPROC_SERVER, &IID_IShellLinkW, (void **)&sl))) {
      if (SUCCEEDED(sl->lpVtbl->QueryInterface(sl, &IID_IPersistFile, (void **)&pf))) {
        if (SUCCEEDED(pf->lpVtbl->Load(pf, p, STGM_READ))) sl->lpVtbl->GetPath(sl, target, MAX_PATH, NULL, SLGP_RAWPATH);
        pf->lpVtbl->Release(pf);
      }
      sl->lpVtbl->Release(sl);
    }
    if (target[0] && (same_file(target, gExe) || same_file(target, gRun))) { DeleteFileW(p); logw(L"удалён ярлык %s", p); }
    else if (gTestCapture) { wb_put(gTestCapture, L"ярлык ведёт на: "); wb_put(gTestCapture, target); wb_putc(gTestCapture, L'\n'); }
  } while (FindNextFileW(f, &fd));
  FindClose(f);
}
static void remove_shortcuts(void) {
  const KNOWNFOLDERID *ids[] = { &FOLDERID_Desktop, &FOLDERID_PublicDesktop, &FOLDERID_Programs, &FOLDERID_CommonPrograms, &FOLDERID_StartMenu };
  for (int i = 0; i < 5; i++) { PWSTR p = NULL; if (SUCCEEDED(SHGetKnownFolderPath(ids[i], 0, NULL, &p)) && p) { remove_shortcuts_in(p, 2); CoTaskMemFree(p); } }
}
static void finish_quit(void);
static void uninstall(int withDocs) {
  gUninstalling = 1; logw(L"удаление svodik%s", withDocs ? L" вместе с документами" : L", документы остаются");
  hide_win();
  { wchar_t cmd[] = L"schtasks.exe /Delete /TN svodik /F"; run_hidden(cmd, 10000, NULL); }
  remove_shortcuts();
  wchar_t p[MAX_PATH]; const wchar_t *dd = data_dir();
  path_join(p, dd, L"update"); delete_tree(p);
  if (withDocs) {
    path_join(p, dd, L"documents"); delete_tree(p); path_join(p, dd, L"files"); delete_tree(p);
    path_join(p, dd, L"settings.json"); DeleteFileW(p);
    if (dir_empty(dd)) RemoveDirectoryW(dd);
  }
  /* старые файлы обновлений рядом с svodik.exe (от версий на Electron) */
  wchar_t exeDir[MAX_PATH], mask[MAX_PATH]; wcscpy(exeDir, gExe); *(wchar_t *)base_name(exeDir) = 0; if (exeDir[0]) exeDir[wcslen(exeDir) - 1] = 0;
  path_join(mask, exeDir, L"svodik-update*"); WIN32_FIND_DATAW fd; HANDLE f = FindFirstFileW(mask, &fd);
  if (f != INVALID_HANDLE_VALUE) { do { path_join(p, exeDir, fd.cFileName); DeleteFileW(p); } while (FindNextFileW(f, &fd)); FindClose(f); }
  /* сам svodik.exe и служебные папки удаляются сразу после выхода (запущенный файл Windows удалить не даёт),
     а на случай, если что-то помешает, — ещё и при следующей перезагрузке */
  WBuf env = {0}; LPWCH cur = GetEnvironmentStringsW();
  for (LPWCH e = cur; *e; e += wcslen(e) + 1) if (!starts_with_i(e, L"SVK_")) { wb_put(&env, e); wb_putc(&env, 0); }
  FreeEnvironmentStringsW(cur);
  wb_put(&env, L"SVK_EXE="); wb_put(&env, gExe); wb_putc(&env, 0);
  wb_put(&env, L"SVK_RUN="); wb_put(&env, gRun); wb_putc(&env, 0);
  wb_put(&env, L"SVK_LOCAL="); wb_put(&env, gLocal); wb_putc(&env, 0);
  wb_put(&env, L"SVK_APP="); wb_put(&env, gAppData); wb_putc(&env, 0); wb_putc(&env, 0);
  wchar_t cmd[] = L"cmd.exe /d /s /c \"ping -n 3 127.0.0.1 >nul & del /f /q \"%SVK_EXE%\" & del /f /q \"%SVK_RUN%\" & rmdir /s /q \"%SVK_LOCAL%\" & rmdir /s /q \"%SVK_APP%\" & ping -n 4 127.0.0.1 >nul & del /f /q \"%SVK_EXE%\" & rmdir /s /q \"%SVK_LOCAL%\"\"";
  DWORD r = run_hidden(cmd, 0, env.p); wb_free(&env);
  MoveFileExW(gExe, NULL, MOVEFILE_DELAY_UNTIL_REBOOT);
  if (_wcsicmp(gRun, gExe)) MoveFileExW(gRun, NULL, MOVEFILE_DELAY_UNTIL_REBOOT);
  logw(L"удаление: команда очистки запущена (%ld)", (long)r);
  g_logPath[0] = 0;   /* журнал удаляется вместе с папкой */
  finish_quit();
}

/* ---------- смена папки документов ---------- */
static void copy_dir_files(const wchar_t *from, const wchar_t *to) {
  wchar_t mask[MAX_PATH], a[MAX_PATH], b[MAX_PATH]; WIN32_FIND_DATAW fd; ensure_dir(to); path_join(mask, from, L"*");
  HANDLE f = FindFirstFileW(mask, &fd); if (f == INVALID_HANDLE_VALUE) return;
  do { if (fd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY || ends_with_i(fd.cFileName, L".tmp")) continue; path_join(a, from, fd.cFileName); path_join(b, to, fd.cFileName); CopyFileW(a, b, FALSE); } while (FindNextFileW(f, &fd));
  FindClose(f);
}
static int choose_data_dir(void) {
  BROWSEINFOW bi = {0}; wchar_t name[MAX_PATH]; bi.hwndOwner = gWnd; bi.pszDisplayName = name; bi.lpszTitle = L"Папка для документов svodik";
  bi.ulFlags = BIF_RETURNONLYFSDIRS | BIF_NEWDIALOGSTYLE;
  set_capture(0); enable_focus_mode();
  PIDLIST_ABSOLUTE pl = SHBrowseForFolderW(&bi); if (!pl) return 0;
  wchar_t target[MAX_PATH]; BOOL ok = SHGetPathFromIDListW(pl, target); CoTaskMemFree(pl);
  if (!ok || !_wcsicmp(target, data_dir())) return 0;
  wchar_t a[MAX_PATH], b[MAX_PATH], s1[MAX_PATH], s2[MAX_PATH]; path_join(a, target, L"documents"); path_join(s2, target, L"settings.json");
  int hasDocs = 0; { wchar_t mask[MAX_PATH]; WIN32_FIND_DATAW fd; path_join(mask, a, L"*.json"); HANDLE f = FindFirstFileW(mask, &fd); if (f != INVALID_HANDLE_VALUE) { hasDocs = 1; FindClose(f); } }
  if (hasDocs || file_exists(s2)) {
    if (MessageBoxW(gWnd, L"В этой папке уже есть документы svodik.\nПереключиться на них? Текущая папка останется как есть.", L"svodik", MB_YESNO | MB_ICONQUESTION) != IDYES) return 0;
  } else {
    path_join(b, data_dir(), L"documents"); copy_dir_files(b, a);
    path_join(b, data_dir(), L"files"); path_join(a, target, L"files"); copy_dir_files(b, a);
    path_join(s1, data_dir(), L"settings.json"); CopyFileW(s1, s2, FALSE);
  }
  wcsncpy(cfg.dataDir, target, MAX_PATH - 1); cfg_save(); ensure_data_dirs();
  logw(L"папка документов: %s", target); navigate_page(); return 1;
}

/* ---------- выход ---------- */
static void finish_quit(void) {
  if (gQuitting == 2) return; gQuitting = 2;
  hooks_stop(); UnregisterHotKey(gWnd, ID_HOTKEY); tray_remove(); stop_timers();
  if (gCtl) { gCtl->lpVtbl->Close(gCtl); }
  DestroyWindow(gWnd);
}
static void quit_app(void) {
  if (gQuitting) return; gQuitting = 1;
  page_wake(0);
  post_type(L"flush"); SetTimer(gWnd, T_QUIT, 1500, NULL);   /* страница допишет настройки и ответит «flushed» */
}

/* ---------- команды от страницы ---------- */
static const wchar_t *arg(wchar_t **a, int n, int i) { return i < n ? a[i] : L""; }
static void on_set(int id, const wchar_t *key, const wchar_t *val) {
  const wchar_t *err = NULL; int recreate = 0;
  if (!wcscmp(key, L"onTop")) { cfg.onTop = _wtoi(val) != 0; apply_top(); }
  else if (!wcscmp(key, L"gameMode")) { cfg.gameMode = _wtoi(val) != 0; set_capture(0); disable_focus_mode(); captureBroken = 0; set_noactivate(cfg.gameMode); recreate = 1; }
  else if (!wcscmp(key, L"retryKeyboard")) { captureBroken = 0; if (win_visible()) set_capture(1); }
  else if (!wcscmp(key, L"captureKeys")) {
    /* сразу видно, что изменилось: клавиатура переходит к svodik или возвращается игре */
    cfg.captureKeys = _wtoi(val) != 0;
    if (GAME() && win_visible() && !focusMode) { if (cfg.captureKeys && !captureBroken) { refresh_game_hwnd(); set_capture(1); } else if (!cfg.captureKeys && capture == 1) set_capture(0); }
  }
  else if (!wcscmp(key, L"lite")) { cfg.lite = _wtoi(val) != 0; if (!cfg.lite) page_wake(win_visible()); else if (!win_visible()) sleep_later(4000); }
  else if (!wcscmp(key, L"alpha")) { double a = _wtof(val); if (a >= .1 && a <= 1) cfg.alpha = a; }
  else if (!wcscmp(key, L"size")) apply_size(val);
  else if (!wcscmp(key, L"mode")) { if (!wcscmp(val, L"clear") || (acrylicOk && !wcscmp(val, L"acrylic"))) { wcscpy(cfg.mode, val); apply_look(); } }
  else if (!wcscmp(key, L"autostart")) err = set_autostart(_wtoi(val) != 0);
  else if (!wcscmp(key, L"autoUpdate")) cfg.autoUpdate = _wtoi(val) != 0;
  else if (!wcscmp(key, L"openData")) open_data_dir();
  else if (!wcscmp(key, L"chooseData")) { PostMessageW(gWnd, WM_APP_CHOOSE, (WPARAM)id, 0); return; }   /* ответим после выбора папки */
  else if (!wcscmp(key, L"quit")) { cfg_save(); quit_app(); }
  else if (!wcscmp(key, L"uninstall")) { cfg_save(); WBuf b = {0}; cfg_json(&b, NULL); reply_raw(id, wb_str(&b)); wb_free(&b); PostMessageW(gWnd, WM_APP_UNINSTALL, wcsstr(val, L"\"docs\":true") != NULL, 0); return; }
  (void)recreate;
  if (!gUninstalling) cfg_save();
  tray_tip();
  WBuf b = {0}; cfg_json(&b, err); reply_raw(id, wb_str(&b)); wb_free(&b);
}
static void on_web_message(const wchar_t *msg) {
  /* «команда␟номер␟аргументы…» */
  wchar_t *copy = _wcsdup(msg), *parts[8]; int n = 0; wchar_t *s = copy;
  while (n < 8) { parts[n++] = s; wchar_t *u = wcschr(s, 0x1F); if (!u) break; *u = 0; s = u + 1; }
  const wchar_t *cmd = parts[0]; int id = n > 1 ? _wtoi(parts[1]) : 0;
  if (!wcscmp(cmd, L"ready")) {
    int first = !gPageReady; gPageReady = 1; push_capture();
    if (first) { if (gShowOnReady || !gStartHidden) { gShowOnReady = 0; show_win(); } else sleep_later(30 * 1000); }
  }
  else if (!wcscmp(cmd, L"hide")) hide_win();
  else if (!wcscmp(cmd, L"set")) on_set(id, arg(parts, n, 2), arg(parts, n, 3));
  else if (!wcscmp(cmd, L"hotkey")) {
    wchar_t old[64]; wcscpy(old, cfg.hotkey); const wchar_t *k = arg(parts, n, 2); WBuf b = {0};
    if (register_hotkey(k)) { wcsncpy(cfg.hotkey, k, 63); cfg_save(); tray_tip(); wb_put(&b, L"{\"ok\":true,\"hotkey\":"); wb_jsonz(&b, cfg.hotkey); wb_putc(&b, L'}'); }
    else { register_hotkey(old); wb_put(&b, L"{\"ok\":false,\"hotkey\":"); wb_jsonz(&b, old); wb_put(&b, L",\"error\":"); WBuf e = {0}; wb_fmt(&e, L"Сочетание %s занято другой программой или Windows. Выберите другое.", k); wb_jsonz(&b, wb_str(&e)); wb_free(&e); wb_putc(&b, L'}'); }
    reply_raw(id, wb_str(&b)); wb_free(&b);
  }
  else if (!wcscmp(cmd, L"hotkeyPause")) { if (_wtoi(arg(parts, n, 2))) UnregisterHotKey(gWnd, ID_HOTKEY); else register_hotkey(cfg.hotkey); }
  else if (!wcscmp(cmd, L"bounds")) {
    RECT r; GetWindowRect(gWnd, &r); double sc = scale_of(gWnd); WBuf b = {0};
    wb_fmt(&b, L"{\"x\":%d,\"y\":%d,\"width\":%d,\"height\":%d}", (int)(r.left / sc), (int)(r.top / sc), (int)((r.right - r.left) / sc), (int)((r.bottom - r.top) / sc));
    reply_raw(id, wb_str(&b)); wb_free(&b);
  }
  else if (!wcscmp(cmd, L"resize")) {
    double sc = scale_of(gWnd); int w = _wtoi(arg(parts, n, 2)), h = _wtoi(arg(parts, n, 3)); if (w < 340) w = 340; if (h < 340) h = 340;
    SetWindowPos(gWnd, NULL, 0, 0, (int)(w * sc), (int)(h * sc), SWP_NOMOVE | SWP_NOZORDER | SWP_NOACTIVATE);
    SetTimer(gWnd, T_SAVEB, 600, NULL);
  }
  else if (!wcscmp(cmd, L"captureToggle")) { if (GAME() && win_visible()) { if (capture == 1) set_capture(0); else if (focusMode) disable_focus_mode(); else want_keyboard(); } }
  else if (!wcscmp(cmd, L"wantKeyboard")) want_keyboard();
  else if (!wcscmp(cmd, L"fx")) { /* разлив красок: курсор передаём, только пока эффект включён */ fxOn = _wtoi(arg(parts, n, 2)) != 0; if (fxOn && win_visible()) SetTimer(gWnd, T_CUR, 16, NULL); else KillTimer(gWnd, T_CUR); }
  else if (!wcscmp(cmd, L"copy")) clip_set(arg(parts, n, 2));
  else if (!wcscmp(cmd, L"drag")) PostMessageW(gWnd, WM_APP_DRAG, 0, 0);
  else if (!wcscmp(cmd, L"docsAll")) fs_docs_all(id);
  else if (!wcscmp(cmd, L"fsList")) fs_list(id, arg(parts, n, 2));
  else if (!wcscmp(cmd, L"fsRead")) fs_read(id, arg(parts, n, 2), _wtoi(arg(parts, n, 3)));
  else if (!wcscmp(cmd, L"fsWrite")) fs_write(id, arg(parts, n, 2), arg(parts, n, 3));
  else if (!wcscmp(cmd, L"fsDel")) fs_del(id, arg(parts, n, 2));
  else if (!wcscmp(cmd, L"flushed")) { if (gQuitting == 1) { KillTimer(gWnd, T_QUIT); PostMessageW(gWnd, WM_APP_QUITNOW, 0, 0); } }
  else if (!wcscmp(cmd, L"openUrl")) { const wchar_t *u = arg(parts, n, 2); if (is_http(u)) ShellExecuteW(NULL, L"open", u, NULL, NULL, SW_SHOWNORMAL); }
  else if (!wcscmp(cmd, L"updateFound")) {
    wcsncpy(gUpdLabel, arg(parts, n, 2), 63); gUpdLabel[63] = 0;
    if (wcscmp(gUpdNotified, gUpdLabel) && !win_visible()) { wchar_t t[200]; _snwprintf(t, 199, L"Вышла версия %s. Откройте svodik (%s), чтобы обновиться.", gUpdLabel, cfg.hotkey); tray_balloon(L"Доступно обновление svodik", t); }
    wcscpy(gUpdNotified, gUpdLabel);
  }
  else if (!wcscmp(cmd, L"download")) {
    if (!InterlockedCompareExchange(&dlBusy, 1, 0)) {
      DlJob *j = (DlJob *)calloc(1, sizeof *j); wcsncpy(j->url, arg(parts, n, 2), 2047); j->size = _wtoi64(arg(parts, n, 3)); wcsncpy(j->tag, arg(parts, n, 4), 63);
      HANDLE th = CreateThread(NULL, 0, dl_thread, j, 0, NULL); if (th) CloseHandle(th); else { free(j); InterlockedExchange(&dlBusy, 0); }
    }
  }
  else if (!wcscmp(cmd, L"install")) {
    const wchar_t *e = install_update(arg(parts, n, 2));
    if (e) { logw(L"установка обновления: %s", e); reply_str(id, e); }
    else { reply_raw(id, L"true"); gQuitting = 1; PostMessageW(gWnd, WM_APP_QUITNOW, 0, 0); }
  }
  else if (!wcscmp(cmd, L"log")) logw(L"страница: %s", arg(parts, n, 2));
  free(copy);
}

/* ---------- окно ---------- */
static void save_bounds(void) { if (!IsIconic(gWnd) && IsWindowVisible(gWnd)) { GetWindowRect(gWnd, &cfg.bounds); cfg.hasBounds = 1; cfg_save(); } }
static LRESULT CALLBACK WndProc(HWND h, UINT m, WPARAM w, LPARAM l) {
  if (m == WM_TASKBARCREATED && WM_TASKBARCREATED) { trayAdded = 0; tray_add(); return 0; }
  switch (m) {
  case WM_APP_KEY: {
    KeyEv *e = (KeyEv *)l; static const struct { UINT vk; const wchar_t *n; } NM[] = { {8, L"Backspace"}, {9, L"Tab"}, {13, L"Enter"}, {27, L"Escape"}, {33, L"PageUp"}, {34, L"PageDown"}, {35, L"End"}, {36, L"Home"}, {37, L"ArrowLeft"}, {38, L"ArrowUp"}, {39, L"ArrowRight"}, {40, L"ArrowDown"}, {45, L"Insert"}, {46, L"Delete"} };
    wchar_t key[16] = {0}, code[16] = {0}; const wchar_t *text = e->text;
    for (size_t i = 0; i < sizeof NM / sizeof NM[0]; i++) if (NM[i].vk == e->vk) { wcscpy(key, NM[i].n); wcscpy(code, NM[i].n); text = L""; }
    if (!key[0] && e->vk >= 0x70 && e->vk <= 0x87) { _snwprintf(key, 15, L"F%u", e->vk - 0x6F); wcscpy(code, key); text = L""; }
    if (!key[0]) {
      if (e->vk >= 'A' && e->vk <= 'Z') _snwprintf(code, 15, L"Key%c", (wchar_t)e->vk); else if (e->vk >= '0' && e->vk <= '9') _snwprintf(code, 15, L"Digit%c", (wchar_t)e->vk); else if (e->vk == 0x20) wcscpy(code, L"Space");
      if (e->text[0]) wcsncpy(key, e->text, 7); else if (e->vk == 0x20) wcscpy(key, L" "); else if (e->vk >= 'A' && e->vk <= 'Z') key[0] = (wchar_t)towlower(e->vk); else if (e->vk >= '0' && e->vk <= '9') key[0] = (wchar_t)e->vk;
      if (!e->text[0] && e->vk == 0x20) text = L" ";
    }
    if (key[0] && capture == 1) {
      WBuf b = {0}; wb_put(&b, L"{\"type\":\"key\",\"k\":{\"key\":"); wb_jsonz(&b, key); wb_put(&b, L",\"code\":"); wb_jsonz(&b, code); wb_put(&b, L",\"text\":"); wb_jsonz(&b, text);
      wb_fmt(&b, L",\"ctrl\":%s,\"shift\":%s,\"alt\":%s}}", e->ctrl ? L"true" : L"false", e->shift ? L"true" : L"false", e->alt ? L"true" : L"false");
      post_json(wb_str(&b)); wb_free(&b);
    }
    free(e); return 0;
  }
  case WM_APP_EDIT: if (capture == 1) edit_cmd((UINT)w, (int)l); return 0;
  case WM_APP_HOT: if (capture == 1) toggle_win(); return 0;
  case WM_APP_WHEEL: {
    WheelEv *e = (WheelEv *)l;
    if (capture == 1) { RECT r; GetWindowRect(h, &r); double sc = scale_of(h); WBuf b = {0}; wb_fmt(&b, L"{\"type\":\"wheel\",\"d\":{\"delta\":%d,\"x\":%d,\"y\":%d}}", e->delta, (int)((e->x - r.left) / sc), (int)((e->y - r.top) / sc)); post_json(wb_str(&b)); wb_free(&b); }
    free(e); return 0;
  }
  case WM_APP_DLPROG: { DlProg *p = (DlProg *)l; WBuf b = {0}; wb_fmt(&b, L"{\"type\":\"dl\",\"received\":%lld,\"total\":%lld}", p->got, p->total); post_json(wb_str(&b)); wb_free(&b); free(p); return 0; }
  case WM_APP_DLDONE: { DlDone *d = (DlDone *)l; WBuf b = {0}; wb_fmt(&b, L"{\"type\":\"dlDone\",\"ok\":%s,\"file\":", d->ok ? L"true" : L"false"); wb_jsonz(&b, d->file); wb_put(&b, L",\"error\":"); wb_jsonz(&b, d->error); wb_putc(&b, L'}'); post_json(wb_str(&b)); wb_free(&b); free(d); return 0; }
  case WM_APP_DRAG: ReleaseCapture(); SendMessageW(h, WM_SYSCOMMAND, SC_MOVE | HTCAPTION, 0); return 0;
  case WM_APP_SHOW: show_win(); return 0;
  case WM_APP_QUITNOW: finish_quit(); return 0;
  case WM_APP_UNINSTALL: uninstall((int)w); return 0;
  case WM_APP_CHOOSE: { choose_data_dir(); WBuf b = {0}; cfg_json(&b, NULL); reply_raw((int)w, wb_str(&b)); wb_free(&b); return 0; }
  case WM_APP_TRAY:
    if (LOWORD(l) == WM_LBUTTONUP) toggle_win();
    else if (LOWORD(l) == WM_RBUTTONUP || LOWORD(l) == WM_CONTEXTMENU) tray_menu();
    else if (LOWORD(l) == NIN_BALLOONUSERCLICK && gUpdLabel[0]) { show_win(); post_type(L"openUpdate"); }
    return 0;
  case WM_HOTKEY: if (w == ID_HOTKEY) toggle_win(); return 0;
  case WM_TIMER:
    if (w == T_FG) { if (capture == 1) { HWND fg = GetForegroundWindow(); if (fg && gameHwnd && fg != gameHwnd && fg != h) set_capture(0); } }   /* ушёл Alt+Tab в другую программу — клавиатуру сразу отдаём */
    else if (w == T_TOP) { if (cfg.onTop) SetWindowPos(h, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE); }   /* игры «без рамки» иногда лезут наверх */
    else if (w == T_CUR) {
      static POINT last = { -1, -1 }; POINT p; RECT r; GetCursorPos(&p); GetWindowRect(h, &r);
      if (PtInRect(&r, p) && (p.x != last.x || p.y != last.y)) { last = p; double sc = scale_of(h); WBuf b = {0}; wb_fmt(&b, L"{\"type\":\"cursor\",\"d\":{\"x\":%d,\"y\":%d}}", (int)((p.x - r.left) / sc), (int)((p.y - r.top) / sc)); post_json(wb_str(&b)); wb_free(&b); }
    }
    else if (w == T_HIDE) { KillTimer(h, T_HIDE); hidePending = 0; stop_timers(); ShowWindow(h, SW_HIDE); sleep_later(4000); }
    else if (w == T_SLEEP) { KillTimer(h, T_SLEEP); page_sleep(); }
    else if (w == T_WAKE) { KillTimer(h, T_WAKE); if (!win_visible()) { page_wake(0); sleep_later(90 * 1000); } }
    else if (w == T_QUIT) { KillTimer(h, T_QUIT); finish_quit(); }
    else if (w == T_SAVEB) { KillTimer(h, T_SAVEB); save_bounds(); }
    else if (w == T_SHOW) { KillTimer(h, T_SHOW); if (!gPageReady) { gPageReady = 1; if (!gStartHidden || gShowOnReady) show_win(); } }
    else if (w == T_CLEAN) {
      static int tries = 0; KillTimer(h, T_CLEAN);
      if (gCleanup[0] && file_exists(gCleanup) && !DeleteFileW(gCleanup) && ++tries < 40) SetTimer(h, T_CLEAN, 1500, NULL);
    }
    return 0;
  case WM_MOUSEACTIVATE: if (GAME() && !focusMode) return MA_NOACTIVATE; break;
  case WM_ACTIVATE: if (LOWORD(w) == WA_INACTIVE) { if (focusMode) disable_focus_mode(); } else if (!GAME() || focusMode) focus_webview(); break;
  case WM_SIZE: resize_webview(); GetWindowRect(h, &capRect); return 0;
  case WM_MOVE: if (gCtl) gCtl->lpVtbl->NotifyParentWindowPositionChanged(gCtl); GetWindowRect(h, &capRect); return 0;
  case WM_EXITSIZEMOVE: save_bounds(); return 0;
  case WM_DPICHANGED: { RECT *r = (RECT *)l; SetWindowPos(h, NULL, r->left, r->top, r->right - r->left, r->bottom - r->top, SWP_NOZORDER | SWP_NOACTIVATE); return 0; }
  case WM_ERASEBKGND: { RECT r; GetClientRect(h, &r); FillRect((HDC)w, &r, (HBRUSH)GetStockObject(BLACK_BRUSH)); return 1; }
  case WM_CLOSE: if (!gQuitting) { hide_win(); return 0; } break;
  case WM_QUERYENDSESSION: return TRUE;
  case WM_ENDSESSION: if (w) { cfg_save(); } return 0;
  case WM_DESTROY: if (gWv) { gWv->lpVtbl->Release(gWv); gWv = NULL; } if (gCtl) { gCtl->lpVtbl->Release(gCtl); gCtl = NULL; } PostQuitMessage(0); return 0;
  }
  return DefWindowProcW(h, m, w, l);
}

/* ---------- запуск ---------- */
static void known_folder(const KNOWNFOLDERID *id, const wchar_t *sub, wchar_t *out) {
  PWSTR p = NULL; out[0] = 0;
  if (SUCCEEDED(SHGetKnownFolderPath(id, KF_FLAG_CREATE, NULL, &p)) && p) { if (sub) path_join(out, p, sub); else wcsncpy(out, p, MAX_PATH - 1); CoTaskMemFree(p); }
}
static int windows_build(void) {
  typedef LONG (WINAPI *RtlGetVersion_t)(OSVERSIONINFOW *); OSVERSIONINFOW v = { sizeof v };
  RtlGetVersion_t f = (RtlGetVersion_t)(void *)GetProcAddress(GetModuleHandleW(L"ntdll.dll"), "RtlGetVersion");
  return f && !f(&v) ? (int)v.dwBuildNumber : 0;
}
/* остатки прежней версии на Electron: её кэш в %APPDATA%\svodik больше не нужен */
static void clean_electron_leftovers(void) {
  if (cfg.cleanedElectron) return;
  const wchar_t *dirs[] = { L"Cache", L"Code Cache", L"GPUCache", L"DawnCache", L"DawnGraphiteCache", L"DawnWebGPUCache", L"Local Storage", L"Session Storage",
    L"Shared Dictionary", L"SharedStorage", L"blob_storage", L"Network", L"Crashpad", L"IndexedDB", L"WebStorage", L"Service Worker", L"Partitions" };
  const wchar_t *files[] = { L"Local State", L"Preferences", L"Network Persistent State", L"Cookies", L"Cookies-journal", L"TransportSecurity", L"Trust Tokens", L"Trust Tokens-journal", L"overlay.json", L"svodik-update.log" };
  wchar_t p[MAX_PATH];
  for (size_t i = 0; i < sizeof dirs / sizeof dirs[0]; i++) { path_join(p, gAppData, dirs[i]); if (dir_exists(p)) delete_tree(p); }
  for (size_t i = 0; i < sizeof files / sizeof files[0]; i++) { path_join(p, gAppData, files[i]); DeleteFileW(p); }
  cfg.cleanedElectron = 1;
}
/* файлы обновлений: в «Документы\svodik\update» и (от версий на Electron) рядом с svodik.exe */
static void clean_update_files(void) {
  wchar_t dir[MAX_PATH], mask[MAX_PATH], p[MAX_PATH]; WIN32_FIND_DATAW fd; HANDLE f;
  path_join(dir, data_dir(), L"update"); path_join(mask, dir, L"*");
  if ((f = FindFirstFileW(mask, &fd)) != INVALID_HANDLE_VALUE) {
    do { if (fd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) continue; path_join(p, dir, fd.cFileName); if (_wcsicmp(p, gRun)) DeleteFileW(p); } while (FindNextFileW(f, &fd));
    FindClose(f);
  }
  if (dir_exists(dir) && dir_empty(dir)) RemoveDirectoryW(dir);
  wchar_t exeDir[MAX_PATH]; wcscpy(exeDir, gExe); *(wchar_t *)base_name(exeDir) = 0; if (exeDir[0]) exeDir[wcslen(exeDir) - 1] = 0;
  path_join(mask, exeDir, L"svodik-update*.exe*");
  if ((f = FindFirstFileW(mask, &fd)) != INVALID_HANDLE_VALUE) {
    do { path_join(p, exeDir, fd.cFileName); if (_wcsicmp(p, gRun)) { SetFileAttributesW(p, FILE_ATTRIBUTE_NORMAL); DeleteFileW(p); } } while (FindNextFileW(f, &fd));
    FindClose(f);
  }
  _snwprintf(p, MAX_PATH - 1, L"%s.new", gExe); DeleteFileW(p);
  _snwprintf(p, MAX_PATH - 1, L"%s.old", gExe); DeleteFileW(p);   /* после прошлого обновления */
}

/* Версия на Electron запускает скачанный svodik.exe так: «--svodik-finish-update <svodik.exe> [<откуда работала>]».
 * Ждём, пока она закроется, ставим себя на место svodik.exe и запускаем его. */
static int legacy_takeover(const wchar_t *target, const wchar_t *prev) {
  logw(L"переход с прежней версии: жду закрытия %s", target);
  for (int t = 0; t < 360; t++) { if (file_free(target) && (!prev[0] || !_wcsicmp(prev, gRun) || file_free(prev))) break; Sleep(500); }
  wchar_t fresh[MAX_PATH + 8]; _snwprintf(fresh, MAX_PATH + 7, L"%s.new", target);
  int ok = 0;
  for (int t = 0; t < 30 && !ok; t++) {
    if (CopyFileW(gRun, fresh, FALSE) && MoveFileExW(fresh, target, MOVEFILE_REPLACE_EXISTING | MOVEFILE_WRITE_THROUGH)) ok = 1;
    else Sleep(700);
  }
  if (!ok) { DeleteFileW(fresh); logw(L"не удалось заменить %s (код %lu) — запускаюсь как есть", target, GetLastError()); return 0; }
  wchar_t cmd[MAX_PATH * 3], cwd[MAX_PATH]; wcscpy(cwd, target); *(wchar_t *)base_name(cwd) = 0;
  _snwprintf(cmd, MAX_PATH * 3 - 1, L"\"%s\" --after-update %lu --cleanup \"%s\"", target, GetCurrentProcessId(), gRun);
  STARTUPINFOW si = { sizeof si }; PROCESS_INFORMATION pi;
  if (!CreateProcessW(target, cmd, NULL, NULL, FALSE, 0, NULL, cwd, &si, &pi)) { logw(L"не удалось запустить %s (код %lu)", target, GetLastError()); return 0; }
  CloseHandle(pi.hThread); CloseHandle(pi.hProcess); logw(L"svodik обновлён: %s", target); return 1;
}

#include "selftest.h"

int WINAPI wWinMain(HINSTANCE hInst, HINSTANCE prev, PWSTR cmdLine, int show) {
  (void)prev; (void)cmdLine; (void)show; gInst = hInst;
  if (selftest_child()) return 0;
  CoInitializeEx(NULL, COINIT_APARTMENTTHREADED);
  GetModuleFileNameW(NULL, gRun, MAX_PATH); wcscpy(gExe, gRun);
  known_folder(&FOLDERID_RoamingAppData, L"svodik", gAppData); known_folder(&FOLDERID_LocalAppData, L"svodik", gLocal);
  known_folder(&FOLDERID_Documents, L"svodik", gDocsDefault);
  ensure_dir(gAppData); path_join(g_logPath, gAppData, L"svodik.log"); path_join(gIni, gAppData, L"svodik.ini");

  int argc = 0; LPWSTR *argv = CommandLineToArgvW(GetCommandLineW(), &argc);
  DWORD waitPid = 0;
  for (int i = 1; i < argc; i++) {
    if (!wcscmp(argv[i], L"--selftest") && i + 1 < argc) return run_selftest(argv[i + 1]);
    if (!wcscmp(argv[i], L"--hidden")) gStartHidden = 1;
    else if (!wcscmp(argv[i], L"--after-update") && i + 1 < argc) { waitPid = (DWORD)_wtoi(argv[++i]); gJustUpdated = 1; }
    else if (!wcscmp(argv[i], L"--cleanup") && i + 1 < argc) wcsncpy(gCleanup, argv[++i], MAX_PATH - 1);
    else if (!wcscmp(argv[i], HELPER_ARG) && i + 1 < argc) {
      const wchar_t *target = argv[i + 1], *prevRun = i + 2 < argc ? argv[i + 2] : L"";
      if (ends_with_i(target, L".exe") && _wcsicmp(target, gRun)) {
        if (legacy_takeover(target, prevRun)) { LocalFree(argv); return 0; }
        gJustUpdated = 1; wcsncpy(gExe, target, MAX_PATH - 1);   /* заменить не вышло — работаем из скачанного файла, а «настоящий» svodik.exe — прежний путь */
      }
      break;
    }
  }
  LocalFree(argv);
  logw(L"svodik %s запущен: %s", APP_VERSION, gRun);

  /* одна копия svodik: вторая просто показывает окно первой; после обновления — ждём, пока закроется старая */
  HANDLE mtx = CreateMutexW(NULL, TRUE, MUTEX_NAME);
  if (GetLastError() == ERROR_ALREADY_EXISTS) {
    DWORD r = WaitForSingleObject(mtx, gJustUpdated ? 30000 : 0);
    if (r != WAIT_OBJECT_0 && r != WAIT_ABANDONED) {
      HWND other = FindWindowW(WND_CLASS, NULL); if (other) PostMessageW(other, WM_APP_SHOW, 0, 0);
      return 0;
    }
  }
  if (waitPid) { HANDLE ph = OpenProcess(SYNCHRONIZE, FALSE, waitPid); if (ph) { WaitForSingleObject(ph, 30000); CloseHandle(ph); } }

  cfg_load();
  isAdmin = IsUserAnAdmin(); acrylicOk = windows_build() >= 22621;
  if (!wcscmp(cfg.mode, L"acrylic") && !acrylicOk) wcscpy(cfg.mode, L"clear");
  clean_electron_leftovers(); clean_update_files(); ensure_data_dirs(); cfg_save();

  WM_TASKBARCREATED = RegisterWindowMessageW(L"TaskbarCreated");
  WNDCLASSEXW wc = { sizeof wc }; wc.lpfnWndProc = WndProc; wc.hInstance = hInst; wc.lpszClassName = WND_CLASS;
  wc.hIcon = LoadIconW(hInst, MAKEINTRESOURCEW(1)); wc.hIconSm = (HICON)LoadImageW(hInst, MAKEINTRESOURCEW(1), IMAGE_ICON, 16, 16, 0);
  wc.hCursor = LoadCursorW(NULL, (LPCWSTR)IDC_ARROW); wc.hbrBackground = (HBRUSH)GetStockObject(BLACK_BRUSH);
  RegisterClassExW(&wc);
  RECT b = cfg.hasBounds && MonitorFromRect(&cfg.bounds, MONITOR_DEFAULTTONULL) ? cfg.bounds : default_bounds();
  gWnd = CreateWindowExW(WS_EX_APPWINDOW | (cfg.onTop ? WS_EX_TOPMOST : 0) | (cfg.gameMode ? WS_EX_NOACTIVATE : 0), WND_CLASS, L"svodik", WS_POPUP | WS_MINIMIZEBOX,
                         b.left, b.top, b.right - b.left, b.bottom - b.top, NULL, NULL, hInst, NULL);
  if (!gWnd) { logw(L"окно не создано: %lu", GetLastError()); return 1; }
  apply_look(); tray_add();
  if (!register_hotkey(cfg.hotkey)) {
    const wchar_t *alt[] = { L"Alt+Q", L"Alt+`", L"Ctrl+Shift+Space", L"F7", L"F9", L"Ctrl+Alt+S" };
    for (int i = 0; i < 6; i++) if (wcscmp(alt[i], cfg.hotkey) && register_hotkey(alt[i])) { wcscpy(cfg.hotkey, alt[i]); cfg_save(); tray_tip(); break; }
  }
  if (cfg.firstRun) { wchar_t t[200]; _snwprintf(t, 199, L"Нажмите %s, чтобы открыть или спрятать окно. Клавишу можно сменить в настройках окна (⚙).", cfg.hotkey); tray_balloon(L"svodik работает", t); cfg.firstRun = 0; cfg_save(); }
  if (gCleanup[0]) SetTimer(gWnd, T_CLEAN, 1500, NULL);
  SetTimer(gWnd, T_SHOW, 8000, NULL);   /* если страница почему-то не ответила — всё равно показываем окно */
  start_webview();

  MSG msg;
  while (GetMessageW(&msg, NULL, 0, 0) > 0) { TranslateMessage(&msg); DispatchMessageW(&msg); }
  hooks_stop(); tray_remove();
  if (gEnv) gEnv->lpVtbl->Release(gEnv);
  if (mtx) { ReleaseMutex(mtx); CloseHandle(mtx); }
  CoUninitialize();
  return 0;
}
